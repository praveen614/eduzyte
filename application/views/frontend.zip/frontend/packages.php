


    <title>Package</title>

    <!-- Fontfaces CSS-->
    <link href="<?php echo base_url();?>assets/member/css/font-face.css" rel="stylesheet" media="all">
    
    <link href="<?php echo base_url();?>assets/member/vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="<?php echo base_url();?>assets/member/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="<?php echo base_url();?>assets/member/vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="<?php echo base_url();?>assets/member/vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <!-- <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all"> -->
    <link href="<?php echo base_url();?>assets/member/vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="<?php echo base_url();?>assets/member/vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="<?php echo base_url();?>assets/member/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="<?php echo base_url();?>assets/member/vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="<?php echo base_url();?>assets/member/css/style.css" rel="stylesheet" media="all">
 
   
<style type="text/css">

    .demo{ background: #b7b7b7; }
.pricingTable{
    padding-bottom: 100px;
    background: #fff;
    text-align: center;
    margin-bottom: 50px;
    position: relative;
}
.pricingTable:before{
    content: "";
    width: 80%;
    height: 10px;
    background: #727cb6;
    margin: 0 auto;
    position: absolute;
    top: -10px;
    left: 0;
    right: 0;
}
.pricingTable .title{
    display: inline-block;
    width: 80%;
    margin: 0 0 40px 0;
    background: #727cb6;
    font-size: 25px;
    font-weight: bold;
    color: #fff;
    letter-spacing: 1px;
    text-transform: uppercase;
    position: relative;
}
.pricingTable .title:before,
.pricingTable .title:after{
    content: "";
    border-right: 10px solid #4a59ab;
    border-top: 10px solid transparent;
    position: absolute;
    top: -10px;
    left: -10px;
}
.pricingTable .title:after{
    border-right: none;
    border-left: 10px solid #4a59ab;
    left: auto;
    right: -10px;
}
.pricingTable .title span{
    display: block;
    padding: 25px 0;
}
.pricingTable .title span:after{
    content: "";
    display: block;
    width: 100%;
    height: 21px;
    position: absolute;
    bottom: -21px;
    background: linear-gradient(-45deg, transparent 75%, #727cb6 75%) 0 50%,linear-gradient( 45deg, transparent 75%, #727cb6 75%) 0 50%;
    background-repeat: repeat-x;
    background-size: 16px;
}
.pricingTable .pricing-content{
    list-style: none;
    padding: 0;
    margin: 0;
}
.pricingTable .pricing-content li{
    font-size: 16px;
    font-weight: bold;
    color: #727cb6;
    line-height: 30px;
    margin-bottom: 20px;
    position: relative;
}
.pricingTable .pricing-content li:last-child{ margin-bottom: 0; }
.pricingTable .pricing-content li:before{
    content: "";
    width: 30px;
    height: 100%;
    background: #727cb6;
    position: absolute;
    top: 0;
    left: -10px;
}
.pricingTable .pricing-content li:after{
    content: "";
    border-left: 15px solid #727cb6;
    border-top: 15px solid transparent;
    border-bottom: 15px solid transparent;
    position: absolute;
    top: 0;
    left: 20px;
}
.pricingTable .pricing-content i{
    font-size: 16px;
    color: #fff;
    position: absolute;
    top: 6px;
    left: 0;
}
.pricingTable .pricing-content i:after{
    content: "";
    border-right: 10px solid #4a59ab;
    border-top: 10px solid transparent;
    position: absolute;
    top: -16px;
    left: -10px;
}
.pricingTable .price-value{
    width: 150px;
    height: 150px;
    border-radius: 50%;
    background: #727cb6;
    margin: 0 auto;
    overflow: hidden;
    position: absolute;
    bottom: -75px;
    left: 0;
    right: 0;
}
.pricingTable .pricingTable-signup{
    display: block;
    padding: 21px 0;
    font-size: 20px;
    font-weight: bold;
    color: #fff;
    position: relative;
}
.pricingTable .pricingTable-signup:before,
.pricingTable .pricingTable-signup:after{
    content: "";
    width: 53%;
    height: 15px;
    background: #fff;
    position: absolute;
    bottom: -5px;
    left: 0;
    transform: rotate(20deg);
}
.pricingTable .pricingTable-signup:after{
    left: auto;
    right: 0;
    transform: rotate(-20deg);
}
.pricingTable .amount{
    display: block;
    padding: 15px 0;
    font-size: 28px;
    font-weight: bold;
    color: #fff;
}
.pricingTable .amount span{
    display: inline;
    font-size: 16px;
    border-bottom: 2px solid #fff;
    position: relative;
    top: -8px;
}
.pricingTable.green:before,
.pricingTable.green .title,
.pricingTable.green .price-value,
.pricingTable.green .pricing-content li:before{
    background: #1abc9c;
}
.pricingTable.green .title span:after{
    background: linear-gradient(-45deg, transparent 75%, #1abc9c 75%) 0 50%,linear-gradient( 45deg, transparent 75%, #1abc9c 75%) 0 50%;
    background-size: 16px;
}
.pricingTable.green .pricing-content li{ color: #1abc9c; }
.pricingTable.green .pricing-content li:after{ border-left: 15px solid #1abc9c; }
.pricingTable.green .title:before,
.pricingTable.green .pricing-content i:after{ border-right: 10px solid #11927a; }
.pricingTable.green .title:after{ border-left: 10px solid #11927a; }
.pricingTable.purple:before,
.pricingTable.purple .title,
.pricingTable.purple .price-value,
.pricingTable.purple .pricing-content li:before{
    background: #cf4d78;
}
.pricingTable.purple .title span:after{
    background: linear-gradient(-45deg, transparent 75%, #cf4d78 75%) 0 50%,linear-gradient( 45deg, transparent 75%, #cf4d78 75%) 0 50%;
    background-size: 16px;
}
.pricingTable.purple .pricing-content li{ color: #cf4d78; }
.pricingTable.purple .pricing-content li:after{ border-left: 15px solid #cf4d78; }
.pricingTable.purple .title:before,
.pricingTable.purple .pricing-content i:after{ border-right: 10px solid #ae365e; }
.pricingTable.purple .title:after{ border-left: 10px solid #ae365e; }
@media only screen and (max-width: 990px){
    .pricingTable{ margin-bottom: 100px; }
}

</style>

<section class="breadcrumb-section contact-bg section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3 text-center">
                        <h1>Package</h1>
                         <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                    </div>
                </div>
            </div>
        </section>

    <div class="container">
        <div class="row"> 
<div class="col-md-12">
<div class="page-wrapper">
        <!-- HEADER MOBILE-->
            <section class="main-content"> 
                 <div class="row">
            <div class="col-md-12" style="text-align: center;">
                <h1>Choose Your Plan</h1>
                
            </div>
            
        </div>
        <br>     

        
<div class="demo">
    <div class="container"> 

        <div class="row">
            <?php
            $package=$this->db->get('package')->result();
            foreach($package as $pack){

             ?>
            <div class="col-md-4 col-sm-6">
                <div class="pricingTable green">
                    <h3 class="title"><span><?php echo strtoupper($pack->type);?></span></h3>
                    <ul class="pricing-content">
                 
                  <div class="container">
                    <i class="fa fa-check"></i>   <p ><?php echo $pack->description;?></p>
                        </div>
                    </ul>
                    
                    <div class="price-value">
                        <a href="<?php  echo site_url();?>/home/register/<?php echo $pack->id;?>" class="pricingTable-signup">select</a>
                        <span class="amount">
                            Rs.<span><?php echo $pack->amount;?></span>
                        </span>
                    </div>
                </div>
            </div>
        <?php }?>
        </div>
    </div>
</div>
 </section>





            <!-- END PAGE CONTAINER-->
        </div>
</div>
    </div>
</div>


    <!-- Jquery JS-->
    <script src="<?php echo base_url();?>assets/member/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="<?php echo base_url();?>assets/member/vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="<?php echo base_url();?>assets/member/vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/member/vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <!-- <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script> -->
    <script src="<?php echo base_url();?>assets/member/vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="<?php echo base_url();?>assets/member/vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="<?php echo base_url();?>assets/member/vendor/circle-progress/circle-progress.min.js"></script>
    <script src="<?php echo base_url();?>assets/member/<?php echo base_url();?>assets/member/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
   <script src="<?php echo base_url();?>assets/member/vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="<?php echo base_url();?>assets/member/js/main.js"></script>


