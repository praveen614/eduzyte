
  <style type="text/css">
          

.message {
  border: 1px solid #d2d0d0;
  padding: 2em;
  font-size: 1.7vw;
  box-shadow: -2px 2px 10px 0px rgba(68, 68, 68, 0.4);
}
@supports (display: grid) {
  .message {
    display: none;
  }
}

.section {
  display: none;
  padding: 2rem;
}
section.section h1 {
    text-align: center;
    padding: 0px 0px 10px;
}
@media screen and (min-width: 768px) {
  .section {
    padding: 4rem;
  }
}
@supports (display: grid) {
  .section {
    display: block;
  }
}

h1 {
  font-size: 2rem;
  margin: 0 0 1.5em;
}

.grid {
    display: grid;
    grid-gap: 35px;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    /* grid-auto-rows: 250px; */
    grid-auto-flow: row dense;
}

.item {
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  box-sizing: border-box;
  background: #949697;
  color: #fff;
  grid-column-start: auto;
  grid-row-start: auto;
  color: #fff;
  background-size: cover;
  background-position: center;
  box-shadow: -2px 2px 10px 0px rgba(68, 68, 68, 0.4);
  transition: -webkit-transform 0.3s ease-in-out;
  transition: transform 0.3s ease-in-out;
  transition: transform 0.3s ease-in-out, -webkit-transform 0.3s ease-in-out;
  cursor: pointer;
  counter-increment: item-counter;
}

.item:after {
  content: '';
  position: absolute;
  width: 100%;
  height: 100%;
  background-color: black;
  opacity: 0.3;
  transition: opacity 0.3s ease-in-out;
}
.item:hover {
  -webkit-transform: scale(1.05);
          transform: scale(1.05);
}
.item:hover:after {
  opacity: 0;
}
.item--medium {
  grid-row-end: span 2;
}
.item--large {
  grid-row-end: span 3;
}
.item--full {
  grid-column-end: auto;
}
@media screen and (min-width: 768px) {
  .item--full {
    grid-column: 1/-1;
    grid-row-end: span 2;
  }
}
.item__details {
  position: relative;
  z-index: 1;
  padding: 15px;
  color: #444;
  background: #fff;
  text-transform: lowercase;
  letter-spacing: 1px;
  color: #828282;
  height: 65px;
}
.item__details:before {
  content: counter(item-counter);
  font-weight: bold;
  font-size: 1.1rem;
  padding-right: 0.5em;
  color: #444;
}

        </style>

<section class="breadcrumb-section contact-bg section-padding">
			<div class="container">
			    <div class="row">
			        <div class="col-md-6 col-md-offset-3 text-center">
			            <h1>GAllery</h1>
			             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
			        </div>
			    </div>
			</div>
		</section><!--Header section end-->
    <div class="container">
    <div class="row">
      <div class="col-md-12">
        <!-- <div class="message">
          Sorry, your browser does not support CSS Grid. 😅
        </div> -->
        <section class="section">
          <h1>My Image Gallery</h1>
          <div class="grid">
            <div class="item">
              <img src="<?php echo base_url();?>assets/img/1.jpg" width="200px">
              <div class="item__details">
                <span>jelly-o brownie sweet</span>
              </div>
            </div>
            <div class="item">
              <img src="assets/img/1.jpg" width="200px">
              <div class="item__details">
                <span>Muffin jelly gingerbread </span>
              </div>
            </div>
            <div class="item">
            <img src="assets/img/1.jpg" width="200px">
              <div class="item__details">
                <span>sesame snaps chocolate</span>
              </div>
            </div>
            <div class="item">
            <img src="assets/img/1.jpg" width="200px">
              <div class="item__details">
                <span>Oat cake</span>
              </div>
            </div>
            <div class="item">
            <img src="assets/img/1.jpg" width="200px">
              <div class="item__details">
                 <span>jujubes cheesecake</span>
              </div>
            </div>
            <div class="item">
            <img src="assets/img/1.jpg" width="200px">
              <div class="item__details">
                <span>Dragée pudding brownie</span>
              </div>
            </div>
            <div class="item">
            <img src="assets/img/1.jpg" width="200px">
              <div class="item__details">
                <span>Oat cake</span>
              </div>
            </div>
            <div class="item">
            <img src="assets/img/1.jpg" width="200px">
              <div class="item__details">
                <span>powder toffee</span>
              </div>
            </div>
            <div class="item">
            <img src="assets/img/1.jpg" width="200px">
              <div class="item__details">
                <span>pudding cheesecake</span>
              </div>
            </div>
            <div class="item">
            <img src="assets/img/1.jpg" width="200px">
              <div class="item__details">
                <span>toffee bear claw </span>
              </div>
            </div>
            <div class="item">
            <img src="assets/img/1.jpg" width="200px">
              <div class="item__details">
                <span>cake cookie croissant</span>
              </div>
            </div>
            <div class="item">
            <img src="assets/img/1.jpg" width="200px">
              <div class="item__details">
                <span>liquorice sweet roll</span>
              </div>
            </div>
            <div class="item">
            <img src="assets/img/1.jpg" width="200px">
              <div class="item__details">
                <span>chocolate marzipan</span>
              </div>
            </div>
            <div class="item">
            <img src="assets/img/1.jpg" width="200px">
              <div class="item__details">
                <span>danish dessert lollipop</span>
              </div>
            </div>
            <div class="item">
            <img src="assets/img/1.jpg" width="200px">
              <div class="item__details">
                <span>sugar plum dragée</span>
              </div>
            </div>
          </div>
        </section>
          </div>
        </div>
      </div>
    </div>