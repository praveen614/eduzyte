

 
    
    <!--header section start-->
			<section class="breadcrumb-section contact-bg section-padding">
			<div class="container">
			    <div class="row">
			        <div class="col-md-6 col-md-offset-3 text-center">
			            <h1>About Us</h1>
			             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
			        </div>
			    </div>
			</div>
			</section><!--Header section end-->
			<!--about us page content start-->
<section class="section-padding about-us-page about-page">
         <div class="container">
             <div class="row">
                 <div class="col-md-6 wow fadeInLeft">
                  <img src="assets/img/about-home-new-bg.png" class="img-responsive img-pdt-btm" alt="About Us Image">
                 </div>
                  <div class="col-md-6">
                  <div class="about-us-content wow fadeInRight">
                      <h2> community</h2>
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Numquam alias repellat esse ratione et ipsam vel minima maxime repudiandae est inventore sit provident corrupti voluptates quisquam quam nihil tempore dignissimos harum, voluptatibus quia. Quas, culpa perspiciatis nisi! Ipsa saepe labore consequuntur.</p>
                     <!--  <a href="#" class="about-btn">Read More</a> -->
                  </div>
                 </div>
             </div>
        </div>
</section>
      
<!--our community member start-->
<section class="section-padding member">
           <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="section-title text-center">
                             <h2>Some Of Our members</h2>
                             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                         </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 col-sm-6 wow fadeInLeft">
                      <div class="single-team-member">
                          <img class="img-shadow" src="https://image.flaticon.com/icons/svg/189/189061.svg" alt="Team Member">
                          <div class="member-hover"> 
                              <a href="#"><i class="fa fa-facebook"></i></a>
                              <a href="#"><i class="fa fa-twitter"></i></a>
                              <a href="#"><i class="fa fa-linkedin"></i></a>
                              <a href="#"><i class="fa fa-instagram"></i></a>
                          </div>
                          <div class="member-name">
                              <h4>Name <span>Member</span></h4>
                          </div>
                      </div>
                    </div>
                    <div class="col-md-3 col-sm-6 wow fadeInLeft">
                      <div class="single-team-member">
                          <img class="img-shadow" src="https://image.flaticon.com/icons/svg/189/189061.svg" alt="Team Member">
                          <div class="member-hover"> 
                              <a href="#"><i class="fa fa-facebook"></i></a>
                              <a href="#"><i class="fa fa-twitter"></i></a>
                              <a href="#"><i class="fa fa-linkedin"></i></a>
                              <a href="#"><i class="fa fa-instagram"></i></a>
                          </div>
                          <div class="member-name">
                           <h4> name <span>Member</span></h4>
                          </div>
                      </div>
                    </div>
                    <div class="col-md-3 col-sm-6 wow fadeInRight">
                      <div class="single-team-member">
                          <img class="img-shadow" src="https://image.flaticon.com/icons/svg/189/189061.svg" alt="Team Member">
                          <div class="member-hover"> 
                              <a href="#"><i class="fa fa-facebook"></i></a>
                              <a href="#"><i class="fa fa-twitter"></i></a>
                              <a href="#"><i class="fa fa-linkedin"></i></a>
                              <a href="#"><i class="fa fa-instagram"></i></a>
                          </div>
                          <div class="member-name">
                          <h4> name <span>Member</span></h4>
                          </div>
                      </div>
                    </div>
                    <div class="col-md-3 col-sm-6 wow fadeInRight">
                        <div class="single-team-member">
                          <img class="img-shadow" src="https://image.flaticon.com/icons/svg/189/189061.svg" alt="Team Member">
                          <div class="member-hover"> 
                              <a href="#"><i class="fa fa-facebook"></i></a>
                              <a href="#"><i class="fa fa-twitter"></i></a>
                              <a href="#"><i class="fa fa-linkedin"></i></a>
                              <a href="#"><i class="fa fa-instagram"></i></a>
                          </div>
                        <div class="member-name">
                        <h4>  Name <span>Member</span></h4>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
</section>
<!--our community member end-->

    <!--pament method section start-->
    <section class="section-padding payment-method payment-bg">
           <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="section-title text-center">
                         <h2>payment method</h2>
                         <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                     </div>
                </div>
            </div>
            <div class="row text-center wow fadeInLeft">
                <div class="col-md-12">
                    <div class="payment-logo">
                        <img src="http://rechargetricks.in/wp-content/uploads/2016/06/Paytm-Logo-400x200.jpeg"  alt="Payment Method Logo">
                        <img src="http://rechargetricks.in/wp-content/uploads/2016/06/Paytm-Logo-400x200.jpeg"  alt="Payment Method Logo">
                        <img src="http://rechargetricks.in/wp-content/uploads/2016/06/Paytm-Logo-400x200.jpeg"  alt="Payment Method Logo">
                        <img src="http://rechargetricks.in/wp-content/uploads/2016/06/Paytm-Logo-400x200.jpeg"  alt="Payment Method Logo">
                    </div>
                </div>
            </div>
         </div>
    </section><!--pament method section end-->

