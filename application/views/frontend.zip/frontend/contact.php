
   
    <!--header section start-->
			<section class="breadcrumb-section contact-bg section-padding">
			<div class="container">
			    <div class="row">
			        <div class="col-md-6 col-md-offset-3 text-center">
			            <h1>contact us</h1>
			             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
			        </div>
			    </div>
			</div>
			</section><!--Header section end-->

      <section class="get-in-touch section-padding text-center">
          <div class="container">
              <div class="row text-center">
                  <div class="col-md-4 wow pulse ">
                      <div class="single-shape-box">
                          <div class="get-in-tuch-icon">
                              <i class="fa fa-phone"></i>
                          </div>
                          <div class="get-in-touch-text">
                              <h4>Call Us</h4>
                              <p>(00) 123456789 </p>
                              <p>(00) 123456789 </p>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-4 wow pulse">
                      <div class="single-shape-box color-onvestor">
                          <div class="get-in-tuch-icon">
                              <i class="fa fa-location-arrow"></i>
                          </div>
                          <div class="get-in-touch-text">
                              <h4>Address </h4>
                              <p> MJR Arcade ,hitex
                               <br /> hyd</p>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-4 wow pulse" >
                      <div class="single-shape-box">
                          <div class="get-in-tuch-icon">
                              <i class="fa fa-envelope"></i>
                          </div>
                          <div class="get-in-touch-text">
                              <h4>Email</h4>
                              <p>example@gmail.com </p>
                              <p>example@gmail.com</p>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <!--get in touch section end-->

			<!--Map section start-->
    <div class="map">
        
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15224.317483269306!2d78.3739363!3d17.4559148!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x3c0f1542a8b97c78!2sGrepthor+Software+Solutions+Pvt+Ltd!5e0!3m2!1sen!2sin!4v1528895360113"  allowfullscreen></iframe>
    </div><!--Map section end-->
      <!--Contact Form Start-->
      <section class="contact-section wow fadeInUp ">
          <div class="container">
              <div class="row">
                  <div class="col-md-12 text-center">
                     <div class="contact-form">
                      <div class="row">
                          <div class="col-md-8 col-md-offset-2">
                                  <h2 class="title">Send Your Masseage</h2>
                                  <form action="http://idealbrothers.thesoftking.com/html/awesomecommunity/contact.html" method="post">
                                      <input type="text" class="name" name="name" placeholder="Name">
                                      <input type="email" class="email" name="email" placeholder="Email">
                                      <textarea name="comment" id="message" cols="30" rows="10" placeholder="Message"></textarea>
                                      <div class="row">
                                          <!-- <div class="col-md-3 col-sm-6">
                                              <p class="captcha-code">125+656=</p>
                                          </div> -->
                                         <!--  <div class="col-md-3 col-sm-6">
                                              <input type="text" class="captcha" name="captcha" placeholder="Answer">
                                          </div> -->
                                          <div class="col-md-6 col-sm-12">
                                              <input type="submit" value="Send Message Now!">
                                          </div>
                                      </div>
                                  </form>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>












