<style type="text/css">
          

.video1 h2 {
    text-align: center;
}
.video1 p {
    text-align: center;
}

.video2 h2 {
    text-align: center;
}
.video2 p {
    text-align: center;
}

.video3 h2 {
    text-align: center;
}
.video3 p {
    text-align: center;
}



.video1 {
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
}
.video2 {
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
}
.video3 {
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
}


h4.heading {
    text-align: center;
    margin-top: 30px;
    margin-bottom: 30px;
    font-size: 30px;
}


/* remove defaults from responsive cols */

.nopadding {
  padding: 2px !important;
  margin: 0 !important;
  outline: 2px solid #333;
  background: #333;
}
.videogal {
  margin-top: 20px;
}


        </style>


<section class="breadcrumb-section contact-bg section-padding">
			<div class="container">
			    <div class="row">
			        <div class="col-md-6 col-md-offset-3 text-center">
			            <h1> Video GAllery</h1>
			             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
			        </div>
			    </div>
			</div>
		</section><!--Header section end-->
    <div class="container ">
       <div class="row">
        <div class="Videos">
          <div class="col-md-12 col-xs-12" style="padding:0px;">
            <h1 style="margin:100px auto 30px auto; text-align:center;">Our video gallery</h1>
         
          <div class="col-md-4 col-xs-12">
            <div class="video1">
              <iframe width="350" height="220" src="https://www.youtube.com/embed/pL_bMl4CTCw" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
               <h2>Video1</h2> 
                <p>Lorem ipsum dolor sit amet, et nam pertinax gloriatur. Sea te minim soleat senserit, ex quo luptatum tacimates voluptatum, salutandi delicatissimi eam ea. In sed nullam laboramus appellantur, mei ei omnis dolorem mnesarchum.</p>
            </div>
          </div>
          <div class="col-md-4 col-xs-12">
            <div class="video2">
              <embed width="350" height="220" src="https://www.youtube.com/v/tgbNymZ7vqY">
                <h2>Video1</h2> 
                <p>Lorem ipsum dolor sit amet, et nam pertinax gloriatur. Sea te minim soleat senserit, ex quo luptatum tacimates voluptatum, salutandi delicatissimi eam ea. In sed nullam laboramus appellantur, mei ei omnis dolorem mnesarchum.</p>
           
            </div>
          </div>
          <div class="col-md-4 col-xs-12">
            <div class="video2">
              <embed width="350" height="220" src="https://www.youtube.com/v/tgbNymZ7vqY">
                <h2>Video1</h2> 
                <p>Lorem ipsum dolor sit amet, et nam pertinax gloriatur. Sea te minim soleat senserit, ex quo luptatum tacimates voluptatum, salutandi delicatissimi eam ea. In sed nullam laboramus appellantur, mei ei omnis dolorem mnesarchum.</p>
            
            </div>
          </div>
          <div class="col-md-4 col-xs-12">
            <div class="video2">
              <embed width="350" height="220" src="https://www.youtube.com/v/tgbNymZ7vqY">
                <h2>Video1</h2> 
                <p>Lorem ipsum dolor sit amet, et nam pertinax gloriatur. Sea te minim soleat senserit, ex quo luptatum tacimates voluptatum, salutandi delicatissimi eam ea. In sed nullam laboramus appellantur, mei ei omnis dolorem mnesarchum.</p>
             
            </div>
          </div>
          <div class="col-md-4 col-xs-12">
            <div class="video2">
              <embed width="350" height="220" src="https://www.youtube.com/v/tgbNymZ7vqY">
                <h2>Video1</h2> 
                <p>Lorem ipsum dolor sit amet, et nam pertinax gloriatur. Sea te minim soleat senserit, ex quo luptatum tacimates voluptatum, salutandi delicatissimi eam ea. In sed nullam laboramus appellantur, mei ei omnis dolorem mnesarchum.</p>
             
            </div>
          </div>
          <div class="col-md-4 col-xs-12">
            <div class="video3">
              <embed width="350" height="220" src="https://www.youtube.com/v/tgbNymZ7vqY">
                <h2>Video1</h2> 
                <p>Lorem ipsum dolor sit amet, et nam pertinax gloriatur. Sea te minim soleat senserit, ex quo luptatum tacimates voluptatum, salutandi delicatissimi eam ea. In sed nullam laboramus appellantur, mei ei omnis dolorem mnesarchum.</p>
             
            </div>
          </div>
          
        </div>

       </div>
      </div>

   



       </div>