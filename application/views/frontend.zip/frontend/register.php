
    <!--main menu start-->
   
    
    <!--header section start-->
		<section class="breadcrumb-section contact-bg section-padding">
			<div class="container">
			    <div class="row">
			        <div class="col-md-6 col-md-offset-3 text-center">
			            <h1>Register</h1>
			             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
			        </div>
			    </div>
			</div>
		</section><!--Header section end-->

<!--login section start-->
<div class="login-section section-padding login-bg">
	<div class="container">
		<div class="row">
			 <div class="col-md-8 col-md-offset-2">
      <div class="main-login main-center">
        
          <form class="form-horizontal" method="post" action="<?php echo base_url()?>home/reg/<?php echo $id;?>">

            <input type="hidden" name="pack_id" value="<?php echo $id;?>">

             <div class="input-group">
                
                 
                </div>

             <div class="row">
              <div class="col-sm-6">
           
              <label for="name" class="cols-sm-2 control-label">Refrence no</label>
              <div class="cols-sm-8">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                  <input type="text" class="form-control" name="refname" id="refname" onchange="return get_position(this.value)" placeholder="Enter your ref_no"/>
                </div>
                <div id="message"></div>
                <span style="color:red; font-size: 12px;"><?php echo form_error('refname');?></span>
              </div>
            
            </div>
              <div class="col-sm-6">
              <label for="name" class="cols-sm-2 control-label">Position</label>
              <div class="cols-sm-8">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                 <select name="position" class="form-control" id="poss">
        <option value="0" selected disabled>Position</option>
   
    </select>
       
                </div>
                <span style="color:red; font-size: 12px;"><?php echo form_error('position');?></span>
              </div>
            </div>
          </div>


            <div class="row">
              <div class="col-sm-6">
           
              <label for="name" class="cols-sm-2 control-label">Pan number</label>
              <div class="cols-sm-8">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                  <input type="text" class="form-control" name="pan" id="pan"  placeholder="Enter your pan"/>
                </div>
                 <span style="color:red; font-size: 12px;"><?php echo form_error('pan');?></span>

              </div>
            
            </div>
              <div class="col-sm-6">
              <label for="name" class="cols-sm-2 control-label">package</label>
              <div class="cols-sm-8">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                  <input type="text" class="form-control" name="package" id="fname"  value="<?php echo $this->db->where('id',$id)->get('package')->row()->type;?>" readonly />
                </div>
                 <span style="color:red; font-size: 12px;"><?php echo form_error('package');?></span>
              </div>
            </div>
          </div>

             
           


             



            <div class="row">
              <div class="col-sm-6">
           
              <label for="name" class="cols-sm-2 control-label">First Name</label>
              <div class="cols-sm-8">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                  <input type="text" class="form-control" name="fname" id="fname"  placeholder="Enter your First Name"/>
                </div>
                 <span style="color:red; font-size: 12px;"><?php echo form_error('fname');?></span>
              </div>
            
            </div>
              <div class="col-sm-6">
              <label for="name" class="cols-sm-2 control-label">Last Name</label>
              <div class="cols-sm-8">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                  <input type="text" class="form-control" name="lname" id="fname"  placeholder="Enter your Last Name"/>
                </div>
                 <span style="color:red; font-size: 12px;"><?php echo form_error('lname');?></span>
              </div>
            </div>
          </div>

           <div class="row">
              <div class="col-sm-6">
           
              <label for="name" class="cols-sm-2 control-label">Email</label>
              <div class="cols-sm-8">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                  <input type="text" class="form-control" name="email" id="emial"  placeholder="Enter your email "/>
                </div>
                 <span style="color:red; font-size: 12px;"><?php echo form_error('email');?></span>
              </div>
            
            </div>
              <div class="col-sm-6">
              <label for="name" class="cols-sm-2 control-label">Mobile</label>
              <div class="cols-sm-8">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                  <input type="text" class="form-control" name="mobile" id="mobile"  placeholder="Enter your mobile No"/>
                </div>
                  <span style="color:red; font-size: 12px;"><?php echo form_error('mobile');?></span>
              </div>
            </div>
          </div>



           <div class="row">
              <div class="col-sm-6">
           
              <label for="name" class="cols-sm-2 control-label">Password</label>
              <div class="cols-sm-8">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                  <input type="password" class="form-control" name="password" id="password"  placeholder="Enter your password"/>
                </div>
                 <span style="color:red; font-size: 12px;"><?php echo form_error('password');?></span>
              </div>
            
            </div>
              <div class="col-sm-6">
              <label for="name" class="cols-sm-2 control-label">Confirm Password</label>
              <div class="cols-sm-8">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
                  <input type="password" class="form-control" name="confirm_password" id="confirm_password"  placeholder="Enter your password"/>
                </div>
                 <span style="color:red; font-size: 12px;"><?php echo form_error('confirm_password');?></span>
                 <small> <span  id="message" ></span></small>
              </div>
            </div>
            
            
          </div>
          <br>
          <label class="checkbox margin-bottom-20">
		<input type="checkbox" name="terms"/>
		<i></i>
		I have read agreed with the <a href="#">terms &amp; conditions</a>
		</label>

         
            <br>

            <div class="form-group ">
              <button type="submit" class="submit-btn btn btn-lg btn-block login-button">Register</button>
            </div>
          </form>
        </div>   
       </div>
		</div>
	</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
  $('#password, #confirm_password').on('keyup', function () {
  if ($('#password').val() == $('#confirm_password').val()) {
    $('#message').html('').css('color', 'green');
  } else 
    $('#message').html('Not Matching').css('color', 'red');
});




  // refer


  function get_position(member_id) {

      $.ajax({
            url: '<?php echo base_url();?>index.php/home/get_position/' + member_id ,
            success: function(response)
            {
                
              if (response == 'failure') {
                 
                  $("#message").html("<div class='error_log'><p class='error' style='color:red'>This Refference ID is not aviliable.</p></div>");
             
        }else {
       
            jQuery('#poss').html(response);
        }
               
            }
        });

    }



</script>