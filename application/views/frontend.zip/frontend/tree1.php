
        <style type="text/css">
            section .hv-container {
    flex-grow: 1;
    overflow: auto;
    justify-content: center; }

.basic-style {
  background-color: #EFE6E2; }
  .basic-style > h1 {
    color: #ac2222; }

/*p.simple-card {
  margin: 0;
  background-color: #fff;
  color: #DE5454;
  padding: 30px;
  border-radius: 7px;
  min-width: 100px;
  text-align: center;
  box-shadow: 0 3px 6px rgba(204, 131, 103, 0.22); }*/

.hv-item-parent p {
  font-weight: bold;
  color: #DE5454; }

.management-hierarchy {
  background-color: #fff; }
  .management-hierarchy > h1 {
    color: #FFF; }
  .management-hierarchy .person {
    text-align: center; }
    .management-hierarchy .person > img {
      height: 110px;
      border: 5px solid #FFF;
      border-radius: 50%;
      overflow: hidden;
      background-color: #fff; }
    .management-hierarchy .person > p.name {
      background-color: #fff;
      padding: 5px 10px;
      border-radius: 5px;
      font-size: 12px;
      font-weight: normal;
      color: #3BAA9D;
      margin: 0;
      position: relative; }
      .management-hierarchy .person > p.name b {
        color: rgba(59, 170, 157, 0.5); }
      .management-hierarchy .person > p.name:before {
        content: '';
        position: absolute;
        width: 2px;
        height: 8px;
        background-color: #fff;
        left: 50%;
        top: 0;
        transform: translateY(-100%); }
        </style>
        
    

                <section class="management-hierarchy">
        
        
        <div class="hv-container">
            <div class="hv-wrapper">

                <!-- Key component -->
                <div class="hv-item col-md-12 col-sm-12 col-xs-12">

                    <div class="hv-item-parent">
                        <div class="person">
                            <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" alt="">
                            <p class="name">
                                Ziko Sichi <b>/ CEO</b>
                            </p>
                        </div>
                    </div>

                    <div class="hv-item-children ">

                        <div class="hv-item-child ">
                            <!-- Key component -->
                            <div class="hv-item ">

                                <div class="hv-item-parent">
                                    <div class="person">
                                       <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" alt="">
                                        <p class="name">
                                            Annie Wilner <b>/ Creative Director</b>
                                        </p>
                                    </div>
                                </div>

                                <div class="hv-item-children">

                                    <div class="hv-item-child">
                                        <div class="person">
                                           <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" alt="">
                                            <p class="name">
                                                Anne Potts <b>/ UI Designer</b>
                                            </p>
                                        </div>
                                    </div>


                                    <!-- <div class="hv-item-child">
                                        <div class="person">
                                            <img src="https://randomuser.me/api/portraits/men/81.jpg" alt="">
                                            <p class="name">
                                                Dan Butler <b>/ UI Designer</b>
                                            </p>
                                        </div>
                                    </div> -->

                                    <div class="hv-item-child">
                                        <div class="person">
                                           <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" alt="">
                                            <p class="name">
                                                Mary Bower <b>/ UX Designer</b>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="hv-item-child">
                                        <div class="person">
                                           <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" alt="">
                                            <p class="name">
                                                Mary Bower <b>/ UX Designer</b>
                                            </p>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>


                        <div class="hv-item-child">
                            <!-- Key component -->
                            <div class="hv-item">

                                <div class="hv-item-parent">
                                    <div class="person">
                                        <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" alt="">
                                        <p class="name">
                                            Gordon Clark <b>/ Senior Developer</b>
                                        </p>
                                    </div>
                                </div>

                                <div class="hv-item-children">

                                    <div class="hv-item-child">
                                        <div class="person">
                                            <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" alt="">
                                            <p class="name">
                                                Harry Bell <b>/ Front-end</b>
                                            </p>
                                        </div>
                                    </div>


                                    <div class="hv-item-child">
                                        <div class="person">
                                            <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" alt="">
                                            <p class="name">
                                                Matt Davies <b>/ Back-end</b>
                                            </p>
                                        </div>
                                    </div>
                                     <div class="hv-item-child">
                                        <div class="person">
                                            <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" alt="">
                                            <p class="name">
                                                Matt Davies <b>/ Back-end</b>
                                            </p>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                         <div class="hv-item-child">
                            <!-- Key component -->
                            <div class="hv-item">

                                <div class="hv-item-parent">
                                    <div class="person">
                                        <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" alt="">
                                        <p class="name">
                                            Gordon Clark <b>/ Senior Developer</b>
                                        </p>
                                    </div>
                                </div>

                                <div class="hv-item-children">

                                    <div class="hv-item-child">
                                        <div class="person">
                                           <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" alt="">
                                            <p class="name">
                                                Harry Bell <b>/ Front-end</b>
                                            </p>
                                        </div>
                                    </div>


                                    <div class="hv-item-child">
                                        <div class="person">
                                           <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" alt="">
                                            <p class="name">
                                                Matt Davies <b>/ Back-end</b>
                                            </p>
                                        </div>

                                    </div>
                                    <div class="hv-item-child">
                                        <div class="person">
                                           <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" alt="">
                                            <p class="name">
                                                Matt Davies <b>/ Back-end</b>
                                            </p>
                                        </div>
                                        
                                    </div>

                                </div>

                            </div>
                        </div>

                    </div>

                </div>

            </div>
        </div>
    </section>
    <!--tree section end-->
	
      





















