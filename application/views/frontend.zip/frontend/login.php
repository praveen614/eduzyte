
    <!--header section start-->
    <section class="breadcrumb-section contact-bg section-padding">
      <div class="container">
          <div class="row">
              <div class="col-md-6 col-md-offset-3 text-center">
                  <h1>Login</h1>
                   <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
              </div>
          </div>
      </div>
    </section><!--Header section end-->

<!--login section start-->
<div class="login-section section-padding login-bg">
  <div class="container">
    <div class="row">
       <div class="col-md-6 col-md-offset-3">
         <div class="main-login main-center">
        <a href="index.html"><img src="<?php echo base_url();?>uploads/logo.png" alt="Logo "></a>
          <form class="form-horizontal" method="post" action="<?php echo base_url();?>index.php/home/login_check">
              
               <div class="form-group">
             
              <div class="cols-sm-10">
               <?php if($this->session->flashdata('msg'))
               {?>
                   
            <p style="color:red;">   <?php  echo  $this->session->flashdata('msg'); ?></p>
             <?php   }?>
              </div>
            </div>

            <div class="form-group">
              <label for="email" class="cols-sm-2 control-label">Username</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
                  <input type="text" class="form-control" name="username" id="username"  placeholder="Enter your username"  />
                  
                </div>
                <span style="color:red"><?php echo form_error('username');?></span>
              </div>
            </div>

            <div class="form-group">
              <label for="password" class="cols-sm-2 control-label">Password</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
                  <input type="password" class="form-control" name="password" id="password"  placeholder="Enter your Password" min="5" max="20" />
                      
                </div>
                <span style="color:red"><?php echo form_error('password');?></span>
              </div>
            </div>
            <p><a href="">forgot password</a></p>

            <div class="form-group ">
              <button type="submit" class="submit-btn btn btn-lg btn-block login-button">Login</button>
            </div>

          </form>

          <div class="row">
            <div class="col-md-6">

          <p><a href=""></a>Dont have account?</p>
          </div>
          <div class="col-md-6 reg_sign">
          <button type="button" class="submit-btn">Signup</button>
          </div>

          </div>
        </div>
       </div>
    </div>
  </div>
</div>

      