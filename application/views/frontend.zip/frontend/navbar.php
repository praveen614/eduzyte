 <div class="mobile-logo">
        <a href="<?php echo base_url();?>home"><img src="<?php echo base_url(); ?>uploads/logo.png" style="max-height:60px;" alt="Logo Image Will Be Here"></a>
    </div>

    <!--main menu start-->
    <nav class="main-menu">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="logo">
                        <a href="<?php echo base_url();?>home"><img src="<?php echo base_url();?>uploads/logo.png" style="max-height:60px;" alt="Logo Image Will Be Here"></a>
                        
                    </div>
                </div>
                <div class="col-md-8 text-right">
                    <nav>
                        <ul id="menu-bar">
                        <li><a href="<?php echo base_url();?>home">Home</a></li>
                        <li><a href="<?php  echo base_url();?>home/about">About Us</a></li>
                        <!-- <li><a href="<?php  echo base_url();?>home/tree">Service</a></li> -->
                            <li><a href="<?php echo  base_url();?>home/photo">Photo</a></li>
                            <li><a href="<?php  echo base_url();?>home/video">Video</a></li>

                        <li><a href="<?php  echo base_url();?>home/contact">Contact</a></li>
                        <li><a href="#">Account <i class="fa fa-caret-down"></i></a>
                        <ul class="sub-menu">
                            <li><a href="<?php echo  base_url();?>home/login">Login</a></li>
                            <li><a href="<?php  echo base_url();?>home/package">Register</a></li>
                        </ul>
                        </li>
                    </ul>
                    </nav>
                </div>
            </div>
        </div>
    </nav><!--main menu end-->