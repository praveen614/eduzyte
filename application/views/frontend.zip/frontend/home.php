
        
    <!--Preloader start-->
    

    
    <!--header section start-->
	<section class="header-section ">
    	<div class="head-slider">
           <div class="single-header slider header-bg">
                   <div class="container">
                            <div class="row">
                                <div class="col-md-8 col-md-offset-2 text-center">
                                    <div class="header-slider-wrapper">
                                        <h1>We Are <br/>MLM</h1>
                                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris . </p>
                                    </div>
                                </div>
                            </div>
                        </div>         
                </div>
                <div class="single-header slider header-bg-2">
                   <div class="container">
                            <div class="row">
                                <div class="col-md-8 col-md-offset-2 text-center">
                                    <h1>welcome to <br/>MLM</h1>
                                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris . </p>
                                </div>
                            </div>
                        </div>         
                </div>         
        </div>
	</section><!--Header section end-->

            <!--about us page content start-->
<section class="section-padding why-should-us">
         <div class="container">
            <div class="row">
                 <div class="col-md-6 col-md-offset-3">
                     <div class="section-title text-center section-padding padding-bottom-0">
                         <h2>Why Should Choose Us</h2>
                         <p>Lorem ipsum dolor si amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                     </div>
                 </div>
             </div>
             <div class="row">
                 <div class="col-md-12 text-center">
                    <div class="what-we-do-wrapper">
                        <div class="column-left wow fadeInLeft">
                           <div class="what-icon">
                           <img src="https://image.flaticon.com/icons/svg/149/149082.svg" alt="Highly Secure">
                           </div>
                           <h4>Highly Secured</h4>
                           <p>Lorem ipsum dolor sit amet. Hic earum dolorum quos, aspernatur omnis iste consequatur rerum eius!</p>
                        </div>
                       <div class="column-center">
                              <div class="what-icon">
                               <img src="https://image.flaticon.com/icons/svg/189/189093.svg" alt="Top Sponsor">
                           </div>
                           <h4>Top Sponsers</h4>
                           <p>Lorem ipsum dolor sit amet. Hic earum dolorum quos, aspernatur omnis iste consequatur rerum eius!</p>
                        </div>
                            
                        <div class="column-right wow fadeInRight">
                        <div class="what-icon">
                               <img src="https://image.flaticon.com/icons/svg/1/1996.svg" alt="Top Sponsor">
                           </div>
                           <h4>Multi Language</h4>
                            <p>Lorem ipsum dolor sit amet. Hic earum dolorum quos, aspernatur omnis iste consequatur rerum eius!</p>
                        </div>
                    </div>
                     <div class="what-we-do-wrapper">
                        <div class="column-left last wow fadeInLeft">
                        <div class="what-icon">
                               <img src="https://image.flaticon.com/icons/svg/138/138255.svg" alt="Top Sponsor">
                           </div>
                           <h4>Multi Currency</h4>
                            <p>Lorem ipsum dolor sit amet. Hic earum dolorum quos, aspernatur omnis iste consequatur rerum eius!</p>
                        </div>
                        <div class="column-center last"><div class="what-icon">
                               <img src="https://image.flaticon.com/icons/svg/149/149066.svg" alt="Top Sponsor">
                           </div>
                           <h4>Refer and Earn</h4>
                            <p>Lorem ipsum dolor sit amet. Hic earum dolorum quos, aspernatur omnis iste consequatur rerum eius!</p>
                        </div>
                        <div class="column-right last wow fadeInRight">
                              <div class="what-icon">
                               <img src="https://image.flaticon.com/icons/svg/265/265668.svg" alt="Top Sponsor">
                           </div>
                           <h4>7/24 Support</h4>
                            <p>Lorem ipsum dolor sit amet. Hic earum dolorum quos, aspernatur omnis iste consequatur rerum eius!</p>
                        </div>
                    </div>
                 </div>
             </div>
        </div>
</section>

     <!--service section start-->
     <section class="section-padding service-section service-bg">
         <div class="container">
             <div class="row">
                 <div class="col-md-6 col-md-offset-3">
                     <div class="section-title text-center section-padding padding-bottom-0">
                         <h2>Our Services</h2>
                         <p>Lorem ipsum dolor si amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                     </div>
                 </div>
             </div>
             <div class="row wow fadeInUp">
                 <div class="col-md-3 col-sm-6">
                    <div class="service-wrapper text-center">
                         <div class="service-icon ">
                             <i class="fa fa-commenting-o"></i>
                         </div>
                         <div class="service-title">
                             <h4>Complete community</h4>
                         </div>
                     </div>
                 </div>
                 <div class="col-md-3 col-sm-6">
                    <div class="service-wrapper text-center ">
                     <div class="service-icon">
                         <i class="fa fa-delicious"></i>
                     </div>
                     <div class="service-title">
                         <h4>Clean Design</h4>
                     </div>
                     </div>
                 </div>
                 <div class="col-md-3 col-sm-6">
                    <div class="service-wrapper text-center">
                     <div class="service-icon">
                         <i class="fa fa-picture-o"></i>
                     </div>
                     <div class="service-title">
                         <h4>cover photos</h4>
                     </div>
                     </div>
                 </div>
                 <div class="col-md-3 col-sm-6">
                    <div class="service-wrapper text-center">
                     <div class="service-icon">
                         <i class="fa fa-plug"></i>
                     </div>
                     <div class="service-title">
                         <h4>plug-ins supported</h4>
                     </div>
                     </div>
                 </div>
                 <div class="col-md-3 col-sm-6">
                    <div class="service-wrapper text-center">
                     <div class="service-icon">
                         <i class="fa fa-plus-square-o"></i>
                     </div>
                     <div class="service-title">
                         <h4>drag &amp; Drop</h4>
                     </div>
                     </div>
                 </div>
                 <div class="col-md-3 col-sm-6">
                    <div class="service-wrapper text-center">
                     <div class="service-icon">
                         <i class="fa fa-share-alt"></i>
                     </div>
                     <div class="service-title">
                         <h4>Social Components</h4>
                     </div>
                     </div>
                 </div>
                 <div class="col-md-3 col-sm-6">
                    <div class="service-wrapper text-center">
                     <div class="service-icon">
                         <i class="fa fa-clock-o"></i>
                     </div>
                     <div class="service-title">
                         <h4>SAVE TIME AND ENERGY</h4>
                     </div>
                     </div>
                 </div>
                 <div class="col-md-3 col-sm-6">
                    <div class="service-wrapper text-center">
                     <div class="service-icon">
                         <i class="fa fa-support"></i>
                     </div>
                     <div class="service-title">
                         <h4>First Class Support</h4>
                     </div>
                     </div>
                 </div>
             </div>
         </div>
     </section><!--service section end-->
     
   
    
    <!--testimonial section start-->
    <section class="section-padding  testimonial-section testimonial-bg">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="section-title text-center">
                         <h2 class="color-text">What People Say</h2>
                     </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                   <div class="slider-activation">
                        <div class="testimonial-carousel">
                            <div class="single-testimonial-wrapper">
                                <div class="single-testimonial-top">
                                   <div class="testimoanial-top-text">
                                        <div class="profile-pic">
                                            <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" class="img-circle img-responsive" alt="Client's Profile Pic">
                                        </div>
                                        <h4 data-animate="flipInX animated">Abir Khan <span>Soft company</span></h4>
                                    </div>
                                    <div class="testimonial-bottom">
                                        <p> <i class="fa fa-quote-left"></i>Lorem ipsum second dolor sit amet, consectetur adipisicing elit, consectetur adipisicing elit, sed do eiusmod  incididunt ut labore et . <i class="fa fa-quote-right"></i></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="testimonial-carousel">
                            <div class="single-testimonial-wrapper">
                                <div class="single-testimonial-top">
                                   <div class="testimoanial-top-text">
                                        <div class="profile-pic">
                                            <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" class="img-circle img-responsive" alt="Client's Profile Pic">
                                        </div>
                                        <h4>Travis hannon <span>Infotech company</span></h4>

                                    </div>
                                    <div class="testimonial-bottom">
                                        <p> <i class="fa fa-quote-left"></i> Lorem ipsum second dolor sit amet, consectetur adipisicing elit, consectetur adipisicing elit, sed do eiusmod  incididunt ut labore et . <i class="fa fa-quote-right"></i></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="testimonial-carousel">
                            <div class="single-testimonial-wrapper">
                                <div class="single-testimonial-top">
                                   <div class="testimoanial-top-text">
                                        <div class="profile-pic">
                                            <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" class="img-circle img-responsive" alt="Client's Profile Pic">
                                        </div>
                                        <h4>Dev Robin <span>King company</span></h4>
                                    </div>
                                    <div class="testimonial-bottom">
                                        <p> <i class="fa fa-quote-left"></i> Lorem ipsum second dolor sit amet, consectetur adipisicing elit, consectetur adipisicing elit, sed do eiusmod  incididunt ut labore et . <i class="fa fa-quote-right"></i></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                   </div>
                   
                </div>
            </div>
        </div>
    </section><!--testimonial section end-->
    
    <!--Deopsit and Payouts section start-->
    <section class="section-padding deposti-section">
        <div class="container">
           <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="section-title text-center">
                         <h2 class="color-text">latest transaction</h2>
                         <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                     </div>
                </div>
            </div>
            <div class="row text-center wow fadeInUp">
                <div class="col-md-12">
                    <ul class="nav nav-tabs deposit-tabs">
                        <li class="active"><a href="#deposit" data-toggle="tab">Latest Deposit</a></li>
                        <li><a href="#withdraw" data-toggle="tab">Latest Withdraw</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="deposit">
                            <table>
                              <thead>
                                <tr>
                                  <th scope="col">Name</th>
                                  <th scope="col">Date</th>
                                  <th scope="col">Currency</th>
                                  <th scope="col">Amount</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td data-label="Account">Name</td>
                                  <td data-label="Due Date">Oct 24,2017</td>
                                  <td data-label="Amount">US</td>
                                  <td data-label="Period">$1.75354</td>
                                </tr>
                               <tr>
                                  <td data-label="Account">Name</td>
                                  <td data-label="Due Date">Oct 24,2017</td>
                                  <td data-label="Amount">US</td>
                                  <td data-label="Period">$1.75354</td>
                                </tr>
                                <tr>
                                  <td data-label="Account">Name</td>
                                  <td data-label="Due Date">Oct 24,2017</td>
                                  <td data-label="Amount">US</td>
                                  <td data-label="Period">$1.75354</td>
                                </tr>
                                <tr>
                                  <td data-label="Account">Name</td>
                                  <td data-label="Due Date">Oct 24,2017</td>
                                  <td data-label="Amount">US</td>
                                  <td data-label="Period">$1.75354</td>
                                </tr>
                                <tr>
                                  <td data-label="Account">Name</td>
                                  <td data-label="Due Date">Oct 24,2017</td>
                                  <td data-label="Amount">US</td>
                                  <td data-label="Period">$1.75354</td>
                                </tr>
                                <tr>
                                  <td data-label="Account">Name</td>
                                  <td data-label="Due Date">Oct 24,2017</td>
                                  <td data-label="Amount">US</td>
                                  <td data-label="Period">$1.75354</td>
                                </tr>
                              </tbody>
                            </table>
                        </div>
                        
                        <div class="tab-pane fade in" id="withdraw">
                            <table>
                              <thead>
                                <tr>
                                  <th scope="col">Name</th>
                                  <th scope="col">Date</th>
                                  <th scope="col">Currency</th>
                                  <th scope="col">Amount</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td data-label="Account">Jhone Doe</td>
                                  <td data-label="Due Date">Oct 24,2017</td>
                                  <td data-label="Amount">bitcoin</td>
                                  <td data-label="Period">.75354 BTC</td>
                                </tr>
                                <tr>
                                  <td  data-label="Account">Jhone Doe</td>
                                  <td data-label="Due Date">Oct 24,2017</td>
                                  <td data-label="Amount">bitcoin</td>
                                  <td data-label="Period">.75354 BTC</td>
                                </tr>
                                <tr>
                                  <td data-label="Account">Jhone Doe</td>
                                  <td data-label="Due Date">Oct 24,2017</td>
                                  <td data-label="Amount">bitcoin</td>
                                  <td data-label="Period">.75354 BTC</td>
                                </tr>
                                <tr>
                                  <td  data-label="Account">Jhone Doe</td>
                                  <td data-label="Due Date">Oct 24,2017</td>
                                  <td data-label="Amount">bitcoin</td>
                                  <td data-label="Period">.75354 BTC</td>
                                </tr>
                                <tr>
                                  <td data-label="Account">Jhone Doe</td>
                                  <td data-label="Due Date">Oct 24,2017</td>
                                  <td data-label="Amount">bitcoin</td>
                                  <td data-label="Period">.75354 BTC</td>
                                </tr>
                                <tr>
                                  <td data-label="Account">Jhone Doe</td>
                                  <td data-label="Due Date">Oct 24,2017</td>
                                  <td data-label="Amount">bitcoin</td>
                                  <td data-label="Period">.75354 BTC</td>
                                </tr>
                                <tr>
                                  <td data-label="Account">Jhone Doe</td>
                                  <td data-label="Due Date">Oct 24,2017</td>
                                  <td data-label="Amount">bitcoin</td>
                                  <td data-label="Period">.75354 BTC</td>
                                </tr>
                              </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!--Deopsit and Payouts Section End-->
    
    
    



















