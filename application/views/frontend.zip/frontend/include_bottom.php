
 <script src="<?php echo base_url();?>front_assets/js/jquery.js"></script>
         <!--Owl carousel script load-->
		<script src="<?php echo base_url();?>front_assets/js/owl.carousel.min.js"></script>
        <!--Bootstrap v3 script load here-->
        <script src="<?php echo base_url();?>front_assets/js/bootstrap.min.js"></script>
        <!--Slick Nav Js File Load-->
        <script src="<?php echo base_url();?>front_assets/js/jquery.slicknav.min.js"></script>
       <!--Wow Js File Load-->
        <script src="<?php echo base_url();?>front_assets/js/wow.min.js"></script>
         <!--Main js file load-->
        <script src="<?php echo base_url();?>front_assets/js/main.js"></script>