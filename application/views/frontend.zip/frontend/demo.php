<?php
$id=2;
$row=$this->db->where('id',$id)->get('member')->result();
echo $row->member_id." ".$row->fname;
echo "<br>";
$down=$this->db->where('reffer_id',$id)->get('member')->result();
foreach ($down as $down) {

	echo $down->member_id." ".$row->fname;
	echo "<br>";
}
?>