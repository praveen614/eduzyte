
        <style type="text/css">
            section .hv-container {
    flex-grow: 1;
    overflow: auto;
    justify-content: center; }

.basic-style {
  background-color: #EFE6E2; }
  .basic-style > h1 {
    color: #ac2222; }


.hv-item-parent p {
  font-weight: bold;
  color: #DE5454; }

.management-hierarchy {
  background-color: #fff; }
  .management-hierarchy > h1 {
    color: #FFF; }
  .management-hierarchy .person {
    text-align: center; }
    .management-hierarchy .person > img {
      height: 110px;
      border: 5px solid #FFF;
      border-radius: 50%;
      overflow: hidden;
      background-color: #fff; }
    .management-hierarchy .person > p.name {
      background-color: #fff;
      padding: 5px 10px;
      border-radius: 5px;
      font-size: 12px;
      font-weight: normal;
      color: #3BAA9D;
      margin: 0;
      position: relative; }
      .management-hierarchy .person > p.name b {
        color: rgba(59, 170, 157, 0.5); }
      .management-hierarchy .person > p.name:before {
        content: '';
        position: absolute;
        width: 2px;
        height: 8px;
        background-color: #fff;
        left: 50%;
        top: 0;
        transform: translateY(-100%); }
        </style>
        
    

                <section class="management-hierarchy">
        
        
        <div class="hv-container">
            <div class="hv-wrapper">

                <!-- Key component -->
                <div class="hv-item col-md-12 col-sm-12 col-xs-12">

                    <?php
$id=2;
$data=$this->db->where('id',$id)->get('member')->result();
foreach ($data as $row) {
  

?>

                    <div class="hv-item-parent">
                        <div class="person">
                            <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" alt="">
                            <p class="name">
                                <?php echo ucfirst($row->fname)."(".$row->member_id.")";?>
                            </p>
                        </div>
                    </div>
                    <?php
                }
                    ?>


                    <div class="hv-item-children ">
                        <?php
                                $down=$this->db->order_by('position')->where('reffer_id',$id)->get('member')->result();
                                  foreach ($down as $down) {


                                 ?>

                        <div class="hv-item-child ">
                            <!-- Key component -->
                            <div class="hv-item ">
                                
                                <div class="hv-item-parent">
                                    <div class="person">
                                       <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" alt="">
                                        <p class="name">
                                            <?php  echo ucfirst($down->fname)."(".$down->member_id.")".$down->position;?>
                                        </p>
                                    </div>
                                </div>
                               

                                <div class="hv-item-children">

                                     <?php
                                $lid=$down->id;

                                 $ldown=$this->db->where('reffer_id',$lid)->get('member')->result();
                                  foreach ($ldown as $ldown) { ?>

                                    <div class="hv-item-child">
                                        <div class="person">
                                           <img src="https://www.jamf.com/jamf-nation/img/default-avatars/generic-user-purple.png" alt="">
                                            <p class="name">
                                                <?php  echo ucfirst($ldown->fname)."(".$ldown->member_id.")";?>
                                            </p>
                                        </div>
                                    </div>

                                     <?php } ?>

                                    

                                </div>
                           
                               

                                

                            </div>

                        </div>
                                <?php
                                }
                                ?>

                       

                    </div>

                </div>

            </div>
        </div>
    </section>
    <!--tree section end-->
	
      





















