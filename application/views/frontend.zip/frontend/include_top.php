
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo $system_name; ?></title>
        <!--Favicon add-->
    <!-- <link rel="shortcut icon" type="image/png" href="<?php echo base_url();?>front_assets/img/fevicon.png"> -->
       <link rel="icon" href="favicon.ico" type="image/x-icon" />
    
        <!--bootstrap Css-->
        <link href="<?php echo base_url();?>front_assets/css/bootstrap.min.css" rel="stylesheet">
        <!--font-awesome Css-->
        <link href="<?php echo base_url();?>front_assets/css/font-awesome.min.css" rel="stylesheet">
        <!--owl.carousel Css-->
        <link href="<?php echo base_url();?>front_assets/css/owl.carousel.css" rel="stylesheet">
        <!--Slick Nav Css-->
        <link href="<?php echo base_url();?>front_assets/css/slicknav.min.css" rel="stylesheet">
        <!--Animate Css-->
        <link href="<?php echo base_url();?>front_assets/css/animate.css" rel="stylesheet">
        <!--Style Css-->
        <link href="<?php echo base_url();?>front_assets/css/style.css" rel="stylesheet">
        <!--Responsive Css-->
        <link href="<?php echo base_url();?>front_assets/css/responsive.css" rel="stylesheet">