<?php
	$system_name        =	$this->db->get_where('settings' , array('type'=>'system_name'))->row()->description;
	//$system_title       =	$this->db->get_where('settings' , array('type'=>'system_title'))->row()->description;

	$running_year 		=   $this->db->get_where('settings' , array('type'=>'running_year'))->row()->description;
	?>
<!DOCTYPE html>
<html lang="zxx">
    

<head>
      <?php include "include_top.php";?>  
    </head>
    <body >
         <div class="preloader">
        <div class="spinner">
          <div class="cube1"></div>
          <div class="cube2"></div>
        </div>
    </div>
    <!--Preloader end-->
    <div class="site"><!--for boxed Layout start-->

    <!--Scroll to top start-->
    <div class="scroll-to-top">
        <a href="#"><i class="fa fa-caret-up"></i></a>
    </div>
<!-- navbar -->

<?php include "navbar.php";?>

        <!-- home page -->



  <?php include $page_name.".php"?>
</div>

<?php include "footer.php";?>
        <!--jquery script load-->

        <?php include "include_bottom.php";?> 
    </body>






















