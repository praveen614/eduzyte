<style>
	.copyright {
    padding: 15px 0;
    border-top: none;
    background: #191919;
}

.copyright p {
    color: #bbb;
    font-size: 12px;
    margin-top: 13px;
    margin-bottom: 0;
}
</style>

<!--=== Footer v4 ===-->
		<div class="footer-v4">



<div class="copyright">
<div class="container">
<div class="row">
<div class="col-md-6">
<p>
&copy; <?php echo date("Y") ?> - . ALL Copy Rights Reserved.
</p>
</div>


<div class="col-md-6">
<p class="pull-right">
<a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a>
</p>
</div>



<!--div class="col-md-6">
<ul class="list-inline sponsors-icons pull-right">
<li><a href="#"><i class="fa fa-cc-paypal"></i></a></li>
<li><a href="#"><i class="fa fa-cc-visa"></i></a></li>
<li><a href="#"><i class="fa fa-cc-mastercard"></i></a></li>
<li><a href="#"><i class="fa fa-cc-discover"></i></a></li>
</ul>
</div-->
</div>
</div>
</div><!--/copyright-->






</div>