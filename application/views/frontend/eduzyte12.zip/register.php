<?php include 'includes/header.php';?>
<!-- <section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>LOGIN</h2>
  </div>
</section> -->
<section style="background-image:url(img/Teacher-and-student.jpg);  background-position: left center; background-image: no-repeat; height: 900px;" class="bg-img">
  <div class="clearfix">
    <div class="col-md-8"></div>
    <div class="col-md-4 login bg-white z-index2 relative skew-section left-bottom">      
      <div class="about-app">
          <div class="section-heading text-center mb-0">
            <h2 class="tutprofile" style="padding-bottom:10px; padding-top: 50px;"><span>Login / <span class="blutxt">Register</span> </span></h2>
          </div>
        </div>
       <div align="center" class="mb-10">
          <span class="togsw"><a href="login.php">Existing User?</a></span>
          <label class="switch">
          <input type="checkbox" value="" checked>
          <span class="slider round"></span>
        </label>
         <span class="togsw1"><a href="register.php">New User?</a></span>
       </div>
       <div class="row">
         <form action="">
          <div class="col-md-4">
            <div class="form-group">
                <select class="form-control input-lg intial">
                  <option>Mr</option>
                  <option>Ms</option>
                  <option>Mrs</option>
                  <option>Dr</option>
                </select>
            </div>
          </div>   
          <div class="col-md-8">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-user-plus"></i></div>
                <input type="text" class="form-control input-lg" placeholder="Firstname" required>
              </div>
            </div>            
          </div>
           <div class="col-md-12">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-envelope"></i></div>
                <input type="text" class="form-control input-lg" placeholder="Email" required>
              </div>
            </div>            
          </div>
          <div class="col-md-12">
            <div class="form-group">
              <input id="phone" type="tel" class="form-control input-lg" placeholder="Mobile Number" required>
            </div>            
          </div>
          <div class="col-md-12">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-key"></i></div>
                <input type="password" class="form-control input-lg" placeholder="Password">
              </div>
            </div>            
          </div>
          <div class="col-md-12">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-refresh"></i></div>
                <input type="password" class="form-control input-lg" placeholder="Retype Password">
              </div>
            </div>            
          </div> 
          <div align="center" class="mb-10">
          <span class="togsw"><a href="login.php">Tutor?</a></span>
          <label class="switch">
          <input type="checkbox" value="" checked>
          <span class="slider round"></span>
        </label>
         <span class="togsw1"><a href="register.php">Student?</a></span>
       </div>  
          <div class="col-md-12">
            <div class="text-center">
              <label for=""><input type="radio"> I agree to <a href="#">Terms and Conditions</a></label>
            </div>
            <div class="form-group">
        <button type="submit" class="btn pull-right" data-toggle="modal" data-target="#confirmModal"><i class="icofont icofont-paper-plane"></i> REGISTER</button>
      </div>
          </div>
         </form>
       </div>
    </div>
  </div>
</section>
<!-- Modal -->
<div class="modal fade" id="confirmModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content text-center">     
      <div class="modal-body forgot">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <h4 class="pt-40">You are selected for tutor registration process. <br>Is it correct?</h4>
                  <hr>             
              <div class="form-group">                
                <button type="button" class="btn" onclick="location.href='otp.php'"><i class="icofont icofont-checked"></i> YES</button>
                <button type="button" class="btn"><i class="icofont icofont-close"></i> NO</button> 
              </div>                
                
      </div>
    </div>
  </div>
</div>
<script>
  $('.timeset select').timezones();
    $("#phone").intlTelInput({
      utilsScript: "js/utils.js"
    });
</script>
<?php include 'includes/footer.php';?>