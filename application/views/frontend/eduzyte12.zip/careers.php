<?php include 'includes/header.php';?>

<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">    
    <div id="overlay"></div>
    <div class="img"></div>    
    <div class="subbgheader">
    	<h2>Careers</h2>
    </div>
</section>
        <section class="ptb-60">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="section-heading text-center">
                            <h2>Join our team</h2>  
                            <p>If you’re passionate and ready to dive in, we’d love to meet you.</p>                        
                        </div>
                    </div>
                </div>
            	<div class="row">
                    <div class="col-md-12 careers">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                            <tr>
                                <th>Job/Post</th>
                                <th>Department</th>
                                <th>Location</th>
                                <th>View</th>
                            </tr>
                            <tr>
                                <td>Partner Account Manager</td>
                                <td>Business Development</td>
                                <td>U.S.A., San Francisco</td>
                                <td align="center"><a href="careers_view.php" class="btn btn-success hvr-bounce-to-right">More Details</a></td>
                            </tr>
                            <tr>
                                <td>Recruiter</td>
                                <td>Employee Success</td>
                                <td>Ireland, Dublin</td>
                                <td align="center"><a href="careers_view.php" class="btn btn-success hvr-bounce-to-right">More Details</a></td>
                            </tr>
                            <tr>
                                <td>Partner Account Manager</td>
                                <td>Business Development</td>
                                <td>U.S.A., San Francisco</td>
                                <td align="center"><a href="careers_view.php" class="btn btn-success hvr-bounce-to-right">More Details</a></td>
                            </tr>
                            <tr>
                                <td>Recruiter</td>
                                <td>Employee Success</td>
                                <td>Ireland, Dublin</td>
                                <td align="center"><a href="careers_view.php" class="btn btn-success hvr-bounce-to-right">More Details</a></td>
                            </tr>
                        </table>
                        </div>
                    </div>
                </div>                                
            </div>
        </section>
<?php include 'includes/footer.php';?>