<?php include 'includes/header.php';?>
<!-- <section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>LOGIN</h2>
  </div>
</section> -->
<section style="background-image:url(img/Teacher-and-student.jpg);  background-position: left center; background-image: no-repeat; min-height: 900px;" class="bg-img">
  <div class="clearfix">
    <div class="col-md-8"></div>
    <div class="col-md-4 login bg-white z-index2 relative skew-section left-bottom">
      <!-- <div class="ptb-10" align="center">
        <img src="img/animlock.gif" width="131" height="99">
      </div> -->
      <div class="about-app">
          <div class="section-heading text-center mb-0">
            <h2 class="tutprofile" style="padding-bottom:10px; padding-top: 35px; margin-bottom: 5px;"><span>Login / <span class="blutxt">Register</span> </span></h2>
          </div>
        </div><br>
       <div align="center" class="mb-10">
          <span class="togsw"><a href="login.php">Existing User?</a></span>
          <label class="switch">
          <input type="checkbox" value="" checked>
          <span class="slider round"></span>
        </label>
         <span class="togsw1"><a href="register.php">New User?</a></span>
       </div>
      <form action="">
        <div class="form-group">
        <div class="input-group">
          <div class="input-group-addon"><i class="fa fa-envelope"></i></div>
          <input type="text" class="form-control input-lg" placeholder="Email / Mobile">
        </div>
      </div>
      <div class="form-group">
        <div class="input-group">
          <div class="input-group-addon"><i class="fa fa-unlock"></i></div>
          <input type="text" class="form-control input-lg" placeholder="Password">
        </div>
      </div>
      <div align="center" class="mb-10">
          <span class="togsw"><a href="login.php">Tutor?</a></span>
          <label class="switch">
          <input type="checkbox" value="" checked>
          <span class="slider round"></span>
        </label>
         <span class="togsw1"><a href="register.php">Student?</a></span>
       </div>
      <div class="form-group">
        <a data-toggle="modal" href="#forgotModal" class="pt-10"><i class="fa fa-question-circle"></i> Forgot Password?</a>
        <button type="submit" class="btn pull-right"><i class="icofont icofont-paper-plane"></i> LOGIN</button>
      </div>
      <div class="ordevider">
          <span>or</span>
      </div>
      <div class="socmedlogin">
        <p>Login With</p>
      <a href="#" class="btn fb"><i class="fa fa-facebook"></i> Facebook</a>
      <a href="#" class="btn gm"><i class="fa fa-google"></i> Gmail</a>
      </div>
      </form>
    </div>
  </div>
</section>
<!-- Modal -->
<div class="modal fade" id="forgotModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">     
      <div class="modal-body forgot">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">FORGOT PASSWORD?</h4> <hr>
              <div class="row">
                <div class="col-md-8 col-md-offset-2">
                  <div class="form-group">
                <div class="input-group">
                  <div class="input-group-addon"><i class="fa fa-envelope"></i></div>
                  <input type="text" class="form-control input-lg" placeholder="Email Address / Mobile">
                </div>
              </div>              
              <div class="form-group">                
                <button type="submit" class="btn"><i class="icofont icofont-paper-plane"></i> SUBMIT</button> 
              </div> 
                </div>
              </div>                             
                
      </div>
    </div>
  </div>
</div>
<?php include 'includes/footer.php';?>