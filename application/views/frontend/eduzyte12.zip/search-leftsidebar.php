
                    <div class="left-sidebar">      
                      <aside class="single-widget">
                            <h6 class="widget-title">Tutor Shortlist</h6>
                            <div class="widget-content categories-widget shrtlist">
                              <div>
                                <span>
                                  <a href="#" class="shimgremove"><i class="fa fa-close"></i></a>
                                <img src="img/tutor1.jpg" class="img-responsive img-circle res-mb-10" width="60" height="60">
                                <small>Title Here</small>
                              </span>
                              <span>
                                  <a href="#" class="shimgremove"><i class="fa fa-close"></i></a>
                                <img src="img/tutor1.jpg" class="img-responsive img-circle res-mb-10" width="60" height="60">
                                <small>Title Here</small>
                              </span>
                              </div>
                              <a href="" class="blubtn">Save Shortlist <i class="fa fa-angle-right"></i></a>
                            </div>
                        </aside>                  
                        <aside class="single-widget">
                            <h6 class="widget-title">LOCATIONS</h6>
                            <div class="widget-content categories-widget locationsel">
                                <ul>
                                    <li><a href="#"><input type="checkbox"> From any Country</a></li>
                                    <li><a href="#"><input type="checkbox"> India</a></li>
                                    <li><a href="#"><input type="checkbox"> Afghanistan</a></li>
                                    <li><a href="#"><input type="checkbox"> Argentina</a></li>
                                    <li><a href="#"><input type="checkbox"> Australia</a></li>
                                    <li><a href="#"><input type="checkbox"> Austria</a></li>
                                    <li><a href="#"><input type="checkbox"> Bahrain</a></li>
                                    <li><a href="#"><input type="checkbox"> Belarus</a></li>
                                    <li><a href="#"><input type="checkbox"> Canada</a></li>
                                    <li><a href="#"><input type="checkbox"> Cayman Islands</a></li>
                                    <li><a href="#"><input type="checkbox"> Cyprus</a></li>
                                    <li><a href="#"><input type="checkbox"> Denmark</a></li>
                                    <li><a href="#"><input type="checkbox"> Egypt</a></li>
                                    <li><a href="#"><input type="checkbox"> France</a></li>
                                    <li><a href="#"><input type="checkbox"> Germany</a></li>
                                </ul>
                            </div>
                        </aside>
                        <aside class="single-widget">
                            <h6 class="widget-title">GENDER</h6>
                            <div class="widget-content">
                                <label><input type="checkbox" name="gender" value="male"> Male</label>
                                <label><input type="checkbox" name="gender" value="female"> Female</label>
                            </div>
                        </aside>                        
                        <aside class="single-widget">
                            <h6 class="widget-title">Experience </h6>
                            <div class="widget-content">
                                <label><input type="checkbox"> 1 Year</label>
                                <label><input type="checkbox"> 2 Years</label>
                                <label><input type="checkbox"> 3 Years</label>
                                <label><input type="checkbox"> 4 Years</label>
                                <label><input type="checkbox"> 5 Years</label>
                            </div>
                        </aside>
                        <aside class="single-widget">
                            <h6 class="widget-title">Age (years)  </h6>
                            <div class="widget-content">
                                <label><input type="checkbox"> Age 18-30 years</label>
                                <label><input type="checkbox"> Age 31-45 years</label>
                                <label><input type="checkbox"> Age 46+ years </label>
                            </div>
                        </aside>                        
                    </div>
                