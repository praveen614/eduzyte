<?php include 'includes/header.php';?>
<!-- <section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>LOGIN</h2>
  </div>
</section> -->
<section style="background-image:url(img/Teacher-and-student.jpg);  background-position: left center; background-image: no-repeat; height: 900px;" class="bg-img">
  <div class="clearfix">
    <div class="col-md-8"></div>
    <div class="col-md-4 login bg-white z-index2 relative skew-section left-bottom">
      <div align="center" class="pt-60 pb-20">
        <img src="img/checkmark.gif" width="80" height="80">
      </div>
      <div class="about-app">
          <div class="section-heading text-center mb-0">
            <h2 class="tutprofile" style="padding-bottom:10px;"><span>Verification </span></h2>
          </div>
        </div>
        <h5 class="text-center">Enter the verification code </h5>
      <form action="">
      <div class="form-group">
        <div class="input-group">
          <div class="input-group-addon"><i class="fa fa-envelope-o"></i></div>
          <input type="text" class="form-control input-lg" placeholder="Enter OTP" required>
        </div>
      </div>
      <div class="form-group clearfix">
        <a href="#" class="btn-link pull-right pt-10"><i class="icofont icofont-refresh"></i> Resend OTP</a>
        <button type="submit" class="btn"><i class="icofont icofont-checked"></i> VERIFY</button>
      </div>
      </form>
      <p class="text-center lh18"><small>If you did not recevie OTP via SMS or your SMS-OTP has expired,please click here to get new OTP to your mobile phone via SMS.</small></p>
    </div>
  </div>
</section>

<?php include 'includes/footer.php';?>