
                  <div class="tutorsearchbox">
                    <div class="row">
                      <div class="col-md-2 col-sm-3 col-xs-12 nopadding">
                        <select class="form-control input-lg seexam">
                          <option>Study Level</option>
                          <option>Elementary (Grade 1 to Grade 5)</option>
                          <option>Secondary (Grade 6 to Grade 10)</option>
                          <option>Seniors Secondary (Grade 11 and Grade 12)</option>
                          <option>Skill Level (Graduation Onwards And All Competitive Exams)</option>
                        </select>
                      </div>
                      <div class="col-md-2 col-sm-3 col-xs-12 nopadding">
                          <select class="form-control input-lg seexam">
                            <option>From Level</option>
                            <option>--Skill Level--</option>
                            <option>Beginner</option>
                            <option>Intermediate</option>
                            <option>Expert</option>
                            <option>--Grades--</option>
                            <option>Grade 1</option>
                            <option>Grade 2</option>
                            <option>Grade 3</option>
                            <option>Grade 4</option>
                            <option>Grade 5</option>
                            <option>Grade 6</option>
                            <option>Grade 7</option>
                            <option>Grade 8</option>
                            <option>Grade 9</option>
                            <option>Grade 10</option>
                            <option>Grade 11</option>
                            <option>A levels</option>
                            <option>Grade 12</option>
                          </select>
                      </div>
                      <div class="col-md-2 col-sm-3 col-xs-12 nopadding">
                          <select class="form-control input-lg seexam">
                            <<option>To Level</option>
                            <option>--Skill Level--</option>
                            <option>Beginner</option>
                            <option>Intermediate</option>
                            <option>Expert</option>
                            <option>--Grades--</option>
                            <option>Grade 1</option>
                            <option>Grade 2</option>
                            <option>Grade 3</option>
                            <option>Grade 4</option>
                            <option>Grade 5</option>
                            <option>Grade 6</option>
                            <option>Grade 7</option>
                            <option>Grade 8</option>
                            <option>Grade 9</option>
                            <option>Grade 10</option>
                            <option>Grade 11</option>
                            <option>A levels</option>
                            <option>Grade 12</option>
                          </select>
                      </div>
                      <div class="col-md-2 col-sm-3 col-xs-12 nopadding">
                <div class="form-group optbtn">
                  <select class="form-control input-lg seexam">
                      <option>Subjects</option>
                      <option>Acadamics</option>
                      <option>Accounting</option>
                      <option>Chemistry</option>
                      <option>Finance</option>
                      <option>Maths</option>
                      <option>Physics</option>
                      <option>Earth Science</option>
                      <option>Social Science</option>
                      <option>StatiStics</option>
                      <option>Botony</option>
                      <option>Zoology</option>
                      <option>Commerce</option>
                      <option>Economics</option>
                      <option>Geology</option>
                      <option>Political Science</option>
                      <option>Psychology</option> 
                      <option>Space Science</option>
                      <option>Philosophy</option>                      
                    </select>
                </div>
            </div>
                      <div class="col-md-2 col-sm-3 col-xs-12 nopadding">
                        <button type="button" class="btn"><i class="icofont icofont-search"></i> Search</button>
                      </div>
                    </div>
                  </div>
               