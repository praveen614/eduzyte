<?php include 'includes/header.php';?>

<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">    
    <div id="overlay"></div>
    <div class="img"></div>    
    <div class="subbgheader">
    	<h2>Partner Account Manager</h2>
    </div>
</section>
        <section class="ptb-60 careers">
            <div class="container">               
            	<div class="row">
                    <div class="col-md-8">                        
                        <h5>JOB DESCRIPTION</h5>
                         <p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos omnis temporibus quod atque, neque inventore ea optio vitae nobis aspernatur debitis provident fugiat dolore tempore corrupti blanditiis porro quia rem! Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos omnis temporibus quod atque, neque inventore ea optio vitae nobis aspernatur debitis provident fugiat dolore tempore corrupti blanditiis porro quia rem!</p>
                         <h5>You are…</h5>
                         <ul>
                             <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos omnis temporibus quod atque</li>
                             <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>
                             <li>Optio vitae nobis aspernatur debitis provident fugiat dolore tempore</li>
                             <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos omnis temporibus quod atque</li>
                             <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>
                             <li>Optio vitae nobis aspernatur debitis provident fugiat dolore tempore</li>
                         </ul>
                         <h5>Qualifications</h5>
                          <ul>
                             <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos omnis temporibus quod atque</li>
                             <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>
                             <li>Optio vitae nobis aspernatur debitis provident fugiat dolore tempore</li>
                             <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos omnis temporibus quod atque</li>
                             <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>
                             <li>Optio vitae nobis aspernatur debitis provident fugiat dolore tempore</li>
                         </ul>
                    </div>
                    <div class="col-md-4">
                        <div class="panel panel-default">                             
                          <div class="panel-body jbover">
                            <span><i class="fa fa-calendar"></i> <strong>Date Posted :</strong><br> Posted 4 months ago</span> 
                             <span><i class="fa fa-map-marker"></i>  <strong>Location :</strong><br> Austin, TX and Mississauga, ON </span> 
                             <span><i class="fa fa-user"></i>  <strong>Job Title :</strong><br> Account Manager </span> 
                             <span><i class="fa fa-check-circle"></i>  <strong>Type :</strong><br> Full-time/Part-Time/Profit Sharing </span><br>
                             <div align="center"><a href="apply_post.php" class="btn btn-primary hvr-bounce-to-right">APPLY FOR JOB</a></div>
                          </div>
                        </div>
                    </div>
                </div>                                
            </div>
        </section>
<?php include 'includes/footer.php';?>