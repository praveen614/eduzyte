<div class="dashboard-tabs-menu">
<ul class="nav nav-tabs nav-justified" role="tablist">
     <li><a href="../profile_email_message_content.php" aria-controls="Profile" role="tab" data-toggle="tab" target="_blank">My Profile</a></li>
     <li <?php if ($page == 'tutor_dashboard.php' || $page == 'tutor_classes_schduled.php' || $page == 'tutor_classes_request_received.php' || $page == 'tutor_classes_request_sent.php' || $page == 'tutor_classes_completed.php') { ?>class="active"<?php } ?>><a href="tutor_dashboard.php" aria-controls="Classes" role="tab" data-toggle="tab">My Classes</a></li>
     <li <?php if ($page == 'tutor_messages.php' || $page == 'tutor_messages_inbox.php' || $page == 'tutor_messages_sent.php' || $page == 'tutor_messages_documents.php' || $page == 'tutor_messages_documents_received.php' || $page == 'tutor_messages_chat_history.php') { ?>class="active"<?php } ?>><a href="tutor_messages.php" aria-controls="Messages" role="tab" data-toggle="tab">Messages(1)</a></li>
     <li <?php if ($page == 'tutor_payments.php' || $page == 'tutor_payments_referrals.php') { ?>class="active"<?php } ?>><a href="tutor_payments.php" aria-controls="Payments" role="tab" data-toggle="tab">Payments</a></li>
     <li <?php if ($page == 'tutor_referrals.php' || $page == 'tutor_view_reffered.php' || $page == 'tutor_view_schemes.php') { ?>class="active"<?php } ?>><a href="tutor_referrals.php" aria-controls="Referrals" role="tab" data-toggle="tab">My Referrals</a></li>
     <li <?php if ($page == 'rate_your_student.php' || $page == 'ratings_by_student.php') { ?>class="active"<?php } ?>><a href="rate_your_student.php">Performance Ratings</a></li>
</ul>
</div>