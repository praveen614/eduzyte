<div class="well">
  <div class="row">
    <div class="col-md-1" align="center">
      <img src="../img/tutor1.jpg" alt="" class="prfimg" width="100" height="100">
    </div>
    <div class="col-md-11 pl-60 pt-20">
      <span>
        <h4>Hello KUMAR</h4>
        <p>Welcome to Eduzyte! On Eduzyte awesome tutors take 1-to-1 live and interactive classes to help you achieve your academic goals! <a href="#" class="blutxt">Start Now.</a></p>
      </span>
    </div>
  </div>
</div>