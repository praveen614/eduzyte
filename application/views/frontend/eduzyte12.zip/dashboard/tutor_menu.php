<div class="left-sidebar">
    <aside class="single-widget dashboard-side-menu">
        <h6 class="widget-title">Tutor Menu</h6>
        <div class="widget-content categories-widget">
            <ul>
                <li <?php if ($page == 'tutors_dash_page.php') { ?>class="active"<?php } ?>><a href="tutors_dash_page.php">All tutors</a></li>
                <li <?php if ($page == 'tutors_my_tutors.php') { ?>class="active"<?php } ?>><a href="tutors_my_tutors.php">My Tutors</a></li>
                <li <?php if ($page == 'tutors_shortlisted.php') { ?>class="active"<?php } ?>><a href="tutors_shortlisted.php">Shortlisted</a></li>
            </ul>
        </div>
    </aside>
</div>