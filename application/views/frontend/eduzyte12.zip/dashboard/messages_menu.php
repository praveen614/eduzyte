<div class="left-sidebar">
    <aside class="single-widget dashboard-side-menu">
        <h6 class="widget-title">Messages Menu</h6>
        <div class="widget-content categories-widget">
            <ul>
                <li <?php if ($page == 'tutor_messages.php') { ?>class="active"<?php } ?>><a href="tutor_messages.php">Compose</a></li>
                <li <?php if ($page == 'tutor_messages_inbox.php') { ?>class="active"<?php } ?>><a href="tutor_messages_inbox.php">Inbox(1)</a></li>
                <li <?php if ($page == 'tutor_messages_sent.php') { ?>class="active"<?php } ?>><a href="tutor_messages_sent.php">Sent Messsages</a></li>
            </ul>
        </div>
    </aside>
</div>