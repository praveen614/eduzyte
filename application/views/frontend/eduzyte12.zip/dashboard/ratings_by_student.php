<?php include 'includes/dashboard_header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>MY DASHBOARD</h2>
  </div>
</section>
<section id="app-about-area" class="ptb-30 dashboard profstep persform">
  <div class="container">  
        <div class="about-app mt-0">
          <?php include 'tutor_welcome.php';?>
          <div class="row">
            <div class="col-md-3">
                  <?php include 'student_rate_menu.php';?>
            </div>
            <div class="col-md-9">
               <?php include 'dashboard_tabmenu.php';?>
               <div id="no-more-tables" class="sr-view">
                  <table class="table table-bordered table-striped table-responsive cf mt-20">
                    <thead class="cf">
                      <tr>
                        <th>Student ID</th>
                        <th>Student Name</th>
                        <th>Rating</th>
                        <th>Testimonial By Student</th>
                      </tr>
                    </thead>
                    <tr>
                      <td data-title="Student ID">&nbsp;</td>
                      <td data-title="Student Name">Kumar</td>
                      <td data-title="Rating">&nbsp;</td>
                      <td data-title="Testimonial By Student">
                        <a href="" class="blutxt" id="ratingshow">Show</a>
                      </td>
                    </tr>
                  </table>
               </div>
            </div>
          </div>
        </div>
  </div>
</section>                                       
<?php include 'includes/dashboard_footer.php';?>
<script>
  $("#ratingshow").click(function(){
        $(this).text("4.5");
    });
</script>