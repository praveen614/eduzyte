<?php include 'includes/header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>EDUCATIONAL QUALIFICATIONS</h2>
  </div>
</section>
<section id="how-it-works-area" class="ptb-60">
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-md-offset-1 profstep">
        <div class="about-app mt-0 single-widget">
          <div class="progress mtmb-20">
          <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 65%">
            Page 3/5
          </div>
        </div>
         <div class="alert alert-success alert-dismissible fade in mb-20" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
            <i class="fa fa-check-circle fa-lg"></i> Subjects Updated
          </div>
         <form action="profile_teaching_details_step.php">
           <div class="row">
             <div class="col-md-7">
          <div class="col-md-12">
            <label>Institution name with city <span class="txt_red">*</span></label>
            <div class="form-group">
              <input type="text" class="form-control input-lg" placeholder="Institution name with city" required>
            </div>            
          </div>
          <div class="col-md-12">
            <label>Degree Name</label>
            <div class="form-group">
              <select class="form-control input-lg seexam">
                <option>-Select Degree-</option>
                <option>BA</option>
                <option>BCom</option>
                <option>B.Sc.</option>
              </select>
            </div>  
             <p style="margin-bottom: 0px;"><a href="#addNewdegree" class="blulink" data-toggle="modal">If not in options in above, add a new Degree</a></p> <br>          
          </div> 

          <div class="col-md-12">
            <label>Specialization <span class="txt_red">*</span></label>
            <div class="form-group">
              <input type="text" class="input-lg form-control" placeholder="Specialization" required>
            </div>
          </div>  
          
          <div class="form-group">
              <button type="submit" class="pull-right mb-20 small-btn"><i class="icofont icofont-plus-circle"></i> ADD QUALIFICATION</button>
            </div>
             </div>
             <div class="col-md-5">
               <div class="row">
             <div class="col-md-12">
          <div class="row">
            <div class="col-md-12">
              <table class="table table-bordered table-striped table-hover addsub">
                <tr>
                  <td>Bsc. (70),<br> Specialization Title</td>
                  <td>
                    <a href="" class="greenbtn btn btn-sm btn-success"><i class="fa fa-edit"></i> EDIT</a>
                    <a href="" class="btn btn-sm btn-danger res-mgt-5"><i class="fa fa-trash-o"></i> DELETE</a>
                  </td>
                </tr>
                <tr>
                  <td>Bsc. (70),<br> Specialization Title</td>
                  <td>
                    <a href="" class="greenbtn btn btn-sm btn-success"><i class="fa fa-edit"></i> EDIT</a>
                    <a href="" class="btn btn-sm btn-danger res-mgt-5"><i class="fa fa-trash-o"></i> DELETE</a>
                  </td>
                </tr>
                <tr>
                  <td>Bsc. (70),<br> Specialization Title</td>
                  <td>
                    <a href="" class="greenbtn btn btn-sm btn-success"><i class="fa fa-edit"></i> EDIT</a>
                    <a href="" class="btn btn-sm btn-danger res-mgt-5"><i class="fa fa-trash-o"></i> DELETE</a>
                  </td>
                </tr>
              </table>
            </div>
          </div>
             </div>
           </div> 
             </div>
           </div><hr>
           <div class="row">
              <div class="col-md-12">
            <div class="form-group">
              <a href="<?=$_SERVER['HTTP_REFERER']?>" class="btn pull-left res-mt-10" ><i class="icofont icofont-simple-left"></i> BACK</a>
        <button type="submit" class="btn pull-right ml-5 res-mt-10">Go To Next Step <i class="fa fa-chevron-right"></i></button>
        <button type="submit" class="btn pull-right res-mt-10"><i class="icofont icofont-save"></i> SAVE</button>
      </div>
          </div>
           </div>
         </form>
       
        </div>
      </div>
    </div>
  </div>
</section>
<!-- app about area start -->
<?php include 'includes/footer.php';?>
<div class="modal fade" id="addNewdegree" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">     
      <div class="modal-body forgot">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Add A New Degree</h4> <hr>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label><strong>Degree Name</strong></label><br>                   
                <div class="input-group">
                  <div class="input-group-addon"><i class="fa fa-sticky-note-o fa-lg"></i></div>
                  <input type="text" class="form-control input-lg" placeholder="subject">
                </div>
                 <small class="text-danger text-center"><strong>Please add only one Degree at a time.</strong></small>
              </div>    <hr>          
              <div class="form-group text-center">                
                <button type="submit" class="btn"><i class="icofont icofont-paper-plane"></i> SAVE</button> 
                <button type="submit" class="btn" data-dismiss="modal"><i class="icofont icofont-close"></i> CANCEL</button> 
              </div> 
                </div>
              </div>                             
                
      </div>
    </div>
  </div>
</div>