<?php include 'includes/header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>TUITION TIMINGS</h2>
  </div>
</section>
<section id="how-it-works-area" class="ptb-60">
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-md-offset-1 profstep">
        <div class="about-app mt-0 single-widget">
          <div class="progress mtmb-20">
          <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 83%">
            Page 5/5
          </div>
        </div> 
        <div class="alert alert-success alert-dismissible fade in mb-20" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
            <i class="fa fa-check-circle fa-lg"></i> Teaching Details Updated
          </div>
         <form action="">
         <div class="col-md-12 mb-20">
<div class="row">
  <div class="col-md-7">
           <div class="timeset">
             <div class="form-group">
               <label for=""><strong>Timezone </strong> <span>*</span></label> <br>
                (Enter correct time zone - it is important for scheduling of your classes.)
                <select class="form-control input-lg seexam"></select>
            </div>
           </div>
            <div class="form-group">
              <label for="">Day <span class="txt_red">*</span></label>
              <select class="form-control input-lg seexam">
                <option>-Select-</option>
                <option>Full Week - Sunday to Saturday</option>
                <option>Weekdays -  Monday to Saturday</option>
                <option>Weekends - Saturday and Sunday</option>
              </select>
              
            </div> 
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label for="">From Time <span class="txt_red">*</span></label>
                <select class="form-control input-lg">
                    <option>-Select-</option>
                    <option>01:00</option>
                    <option>02:00</option>
                    <option>03:00</option>
                    <option>04:00</option>
                    <option>05:00</option>
                    <option>06:00</option>
                    <option>07:00</option>
                    <option>08:00</option>
                    <option>09:00</option>
                    <option>10:00</option>
                    <option>11:00</option>
                    <option>12:00</option>
                  </select>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="">To Time <span class="txt_red">*</span></label>
                <select class="form-control input-lg">
                    <option>-Select-</option>
                    <option>01:00</option>
                    <option>02:00</option>
                    <option>03:00</option>
                    <option>04:00</option>
                    <option>05:00</option>
                    <option>06:00</option>
                    <option>07:00</option>
                    <option>08:00</option>
                    <option>09:00</option>
                    <option>10:00</option>
                    <option>11:00</option>
                    <option>12:00</option>
                  </select>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="">Period <span class="txt_red">*</span></label>
                <select class="form-control input-lg">
                    <option>-Select-</option>
                    <option>AM</option>
                    <option>PM</option>
                  </select>
              </div>
            
            </div>
            <a href="#" class="mb-10 blutxt pull-right"><i class="fa fa-plus-circle"></i> Add Timings</a>
          </div>
  </div>
  <div class="col-md-5">
               <div class="row">
             <div class="col-md-12">
               <div class="alert alert-success alert-dismissible fade in" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
            <i class="fa fa-check-circle fa-lg"></i> Tuition Timings added
          </div>
          <div class="row">
            <div class="col-md-12">
              <table class="table table-bordered table-striped table-hover addsub">
                <tr>
                  <td>Full Week <br> Sunday To Saturday <br>
                  4:00 to 5:00 PM</td>
                  <td>
                    <a href="" class="greenbtn btn btn-sm btn-success"><i class="fa fa-edit"></i> EDIT</a>
                    <a href="" class="btn btn-sm btn-danger res-mgt-5"><i class="fa fa-trash-o"></i> DELETE</a>
                  </td>
                </tr>
              </table>
            </div>
          </div>
             </div>
           </div> 
             
  </div>
</div>


<div class="modal fade bs-example-modal-sm" id="exTimes" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">     
      <div class="modal-body forgot">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Timings Notice</h4> <hr>
              <div class="row">
                <div class="col-md-12">
                 Timings can be selected one hour at a time only ( Eg: 05:00 to 06:00 PM).
If you need to teach for multiple timings then click on ADD TIMINGS
                </div>
              </div>  
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn" data-dismiss="modal">OK</button> 
      </div>
    </div>
  </div>
</div>
         </div>

         <div class="col-md-12">
            <div class="form-group">
              <a href="<?=$_SERVER['HTTP_REFERER']?>" class="btn pull-left" ><i class="icofont icofont-simple-left"></i> BACK</a>

              <button type="submit" class="btn pull-right mg-20 res-mt-10"><i class="icofont icofont-save"></i> SAVE & CONTINUE</button>
              <button type="submit" class="btn pull-right res-mt-10"><i class="icofont icofont-save"></i> SAVE</button>
        
      </div>
          </div>
         
         </form>
       
        </div>
      </div>
    </div>
  </div>
</section>
<!-- app about area start -->
<script src="js/timezones.full.js"></script>
<script>
    $('.timeset select').timezones();
  $(function () {
   $('[data-toggle="tooltip"]').tooltip()
})
</script>
<?php include 'includes/footer.php';?>
