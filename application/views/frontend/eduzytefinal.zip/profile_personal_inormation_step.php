<?php include 'includes/header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>PERSONAL INFORMATION</h2>
  </div>
</section>
<section id="how-it-works-area" class="ptb-60">
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-md-offset-1 profstep">
        <div class="about-app mt-0 single-widget">
          <div class="progress mtmb-20">
          <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 25%">
            Page 1/5
          </div>
        </div>
        <div class="row">
            <div class="col-md-12">
              <h4 class="blutxt">Personal Information</h4> <hr>
            </div>
          </div>
         <form action="profile_subject_step.php" class="persform">
              <div class="col-md-4 col-sm-4">
            <div class="form-group">
              <label for=""><strong>Salutation</strong> <span>*</span></label>
                <select class="form-control input-lg intial">
                  <option>Please Select Salutation</option>
                  <option>Mr.</option>
                  <option>Ms.</option>
                  <option>Mrs.</option>
                  <option>Dr.</option>
                  <option>Other</option>
                </select>
            </div>
          </div> 
             
          <div class="col-md-4 col-sm-4">
            <div class="form-group">
              <label for=""><strong>Firstname</strong> <span>*</span></label>
              <input type="text" class="form-control input-lg" value="Kumar">
            </div>            
          </div>
          <div class="col-md-4 col-sm-4">
            <div class="form-group">
              <label for=""><strong>Lastname</strong> <span>*</span></label>
              <input type="text" class="form-control input-lg" placeholder="Enter Lastname">
            </div>            
          </div>
          
          <div class="col-md-12 col-sm-12">
            <div class="form-group">
              <label for=""><strong>Display Name</strong></label><br>
            <small>(Your first name followed by your lastname will appear as default in case you do not enter a display name)</small>
            <input type="text" class="form-control input-lg">
            </div>
          </div>  
          <div class="col-md-12 col-sm-12">
            <div class="form-group">
              <label for=""><strong>Profile Photo</strong> <span>*</span></label><br>
            <small>(The photo should be a high resolution, recently taken calear image of your face. While getting photo clicket, look directly into the camera. Maximum size allowed for upload - 1 MB. We recommend you to upload 3 different pictures for your profile photo.)</small>
            </div>
          </div> 
          <div class="col-md-6">
            <div class="form-group">
              Picture 
              <input type="file" class="form-control input-lg">
            </div>
          </div>
          <div class="col-md-1 pt-30">(OR)</div> 
          <div class="col-md-5">
            <div class="form-group">
              Take a Picture From Webcam (Size : 180 x180)
              <input type="file" class="form-control input-lg">
            </div>
          </div>  
          <div class="col-md-3">
            <label for=""><strong>Gender</strong> <span>*</span></label>
            <div class="form-group">
              <select class="form-control input-lg teach">
                <option>Please Select</option>
                <option>Male</option>
                <option>Female</option>
                <option>Other</option>
              </select>
            </div>
          </div>
          <div class="col-md-6">
            <label for=""><strong>Date of Birth</strong> <span>*</span></label>
            <div class="form-group">
              <input type="text" placeholder="Enter Date of Birth" disabled class="form-control input-lg">
            </div>
          </div>
          <div class="col-md-12">
            <div class="form-group">
              <label for=""><strong>Government Photo Identity Card</strong> <span>*</span></label> <br>
            <small>(Please upload a clear scanned copy of a government Photo Identity from the list provided via the drop down menu.)</small>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <select class="form-control input-lg teach">
                <option>Income Tax Pan Card</option>
                <option>Photo Credit Card</option>
                <option>Voter ID Card</option>
                <option>Passport</option>
                <option>Arm's Licence</option>
                <option>Driving Licence</option>
                <option>Identity Card issued by Central / State Government</option>
                <option>Identity Card issued by Public Sector Undertakings</option>
                <option>Ration Card with your Photo</option>
                <option>Government College / University Identity Card</option>
              </select>
            </div>
          </div>
          <div class="col-md-6">
            <input type="file" class="form-control input-lg">
          </div>
          <div class="col-md-12">
            <div class="form-group res-mt-10">
              <input type="checkbox" data-toggle="modal" data-target="#GPICModal"> Skip for now - I will upload later.
            </div>
          </div>
          <div class="col-md-12">
            <label for=""><strong>PAN Details</strong> <span>*</span></label>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <input type="radio" class="enterpan" name="pan"> Enter Your PAN <br>
              <input type="text"  class="showpan form-control input-lg" style="display: none" placeholder="Enter Your PAN" id="hdpan">
            </div>
          </div>
          <div class="col-md-4">
            <input type="radio" onclick="donPAN()" name="pan"> I dont have a PAN
          </div>
          <div class="clear-fix"></div>
          <div class="col-md-12">
            <h4 class="blutxt">Communication Details</h4><hr>
          </div>
          <div class="col-md-12">
            <p>(This information is required for Eduzyte internal record and will not be displayed on your tutor profile.)</p> <hr>
          </div>
          <div class="col-md-12">
            <label for=""><strong>Address for Correspondence</strong></label>
            <div class="form-group"><span class="astred">*</span>
              <input type="text" class="form-control input-lg" placeholder="Address Line 1"> 
            </div>
          </div>
          
          <div class="col-md-6">
            <div class="form-group"><span class="astred">*</span>
              <input type="text" class="form-control input-lg" placeholder="City/Town"> 
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group"><span class="astred">*</span>
              <input type="text" class="form-control input-lg" placeholder="Zip/Postal Code">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group"><span class="astred">*</span>
              <input type="text" class="form-control input-lg" placeholder="Landmark">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group"><span class="astred">*</span>
              <input type="text" class="form-control input-lg" placeholder="State/Province">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group"><span class="astred">*</span>
              <select class="input-lg form-control teach" style="line-height: 20px;">
                <option value="">Country</option>
                <option value="">India</option>
                <option value="">USA</option>
              </select>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group"><span class="astred">*</span>
              <input type="text" class="form-control input-lg" placeholder="Home Town">
            </div>
          </div>
          <div class="col-md-12">
            <label for=""><strong>Current Address Proof</strong> <span>*</span></label><br>
            (Please provide a clear scanned copy of your address proof from the list provided via the drop down menu.)
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <select class="form-control input-lg teach">
                <option>Electricity Bill of State company (Not older than last 3 months)</option>
                <option>Telephone Bill of Fixed Line (not older than last 3 months)</option>
                <option>Water Bill (not older than last 3 months)</option>
                <option>Ration card</option>
                <option>Income Tax Assessment Order (not older than one year)</option>
                <option>Vehicle Registration Certificate (RC)</option>
                <option>Registered Sale/Lease(Rent) Agreement</option>
                <option>College ID card along with a letter from College admistration with hostel details</option>
              </select>
            </div>
          </div>
          <div class="col-md-6">
            <input type="file" class="form-control input-lg">
          </div>
          <div class="col-md-12">
            <div class="form-group res-mt-10">
              <input type="checkbox" data-toggle="modal" data-target="#CAPModal"> Skip for now - I will upload later.
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label for=""><strong>Primary Contact Number </strong> <span>*</span></label>
            <input id="phone" type="tel" class="form-control input-lg" placeholder="Primary Contact No.">
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label for=""><strong>Secondary Contact Number </strong></label>
              <input id="phone1" type="tel" class="form-control input-lg" placeholder="Enter Your Phone No.">
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label for=""><strong>Whatsapp Number </strong></label>
            <input id="phone2" type="tel" class="form-control input-lg" placeholder="Whatsapp Number">
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label for=""><strong>Skype ID</strong> <span>*</span></label>
              <div class="input-group">
                <div class="input-group-addon" style="background-color: #fff; border:1px solid #ccc; border-right:0px; color: #05adff"><i class="fa fa-skype fa-lg"></i></div>
                <input type="text" class="form-control input-lg" placeholder="Skype ID">
              </div>
            </div>
          </div>
          <div class="clear-fix"></div>
          <div class="col-md-6">
            <div class="form-group">
              <label for=""><strong>Primary Email Address </strong> <span>*</span></label>
            <input type="text" class="form-control input-lg" value="info@kumar.com" disabled>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for=""><strong>Secondary Email Address </strong></label>
            <input type="text" class="form-control input-lg" placeholder="Enter Your Email Address">
            </div>
          </div>
          <div class="col-md-12">
            <h4 class="blutxt">Social Links</h4> <hr>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-facebook"></i></div>
                <input type="text" class="form-control input-lg" placeholder="Facebook Profile">
              </div>
            </div>
          </div> 
          <div class="col-md-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-twitter"></i></div>
                <input type="text" class="form-control input-lg" placeholder="Twitter Profile">
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-linkedin"></i></div>
                <input type="text" class="form-control input-lg" placeholder="Linkedin Profile">
              </div>
            </div>
          </div> 
          <div class="col-md-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-youtube"></i></div>
                <input type="text" class="form-control input-lg" placeholder="Video Credentials">
              </div>
            </div>
          </div>
          <!-- <div class="col-md-12 timeset">
            <div class="form-group">
               <label for=""><strong>Timezone </strong> <span>*</span></label> <br>
                (Enter correct time zone - it is important for scheduling of your classes.)
                <select class="form-control input-lg seexam"></select>
            </div>
          </div> -->
          <div class="col-md-12">
            <div class="form-group">
       <a href="<?=$_SERVER['HTTP_REFERER']?>" class="btn pull-left res-mt-10" ><i class="icofont icofont-simple-left"></i> BACK</a>
        <button type="submit" class="btn pull-right res-mt-10"><i class="icofont icofont-save"></i> SAVE & CONTINUE</button>
      </div>
          </div>
         </form>
       
        </div>
      </div>
    </div>
  </div>
</section>
<!-- app about area start -->
<script src="js/timezones.full.js"></script>
<link rel="stylesheet" href="css/intlTelInput.css">
<script src="js/intlTelInput.js"></script>
<script>
    $('.timeset select').timezones();
    $("#phone,#phone1,#phone2").intlTelInput({
      utilsScript: "js/utils.js"
    });
    function donPAN(){
      //$(".showpan").hide();
      alert('Please note that disbursement of payments for tutoring services provided, for example, tutoring session taken, content submission-articles,quizzes, etc.Will be done only after PAN card is submitted at Eduzyte.');
    }
    $(".enterpan").click(function(){
    $(".showpan").toggle();
    });

</script>
<?php include 'includes/footer.php';?>

  <!-- Modal -->
<div class="modal fade" id="GPICModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">     
      <div class="modal-body forgot">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Government Photo Identity Card</h4> <hr>
              <div class="row">
                <div class="col-md-12">
                  <p>Please not that disbursement of payments for tutoring services provided, for example, tutoring sessions taken, content submission articles, quizzes, etc. will be done only after a valid government photo id card is submitted at Eduzyte.</p>  
                </div>
              </div>  
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn" data-dismiss="modal">OK</button> 
      </div>
    </div>
  </div>
</div>

  <!-- Modal -->
<div class="modal fade" id="CAPModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">     
      <div class="modal-body forgot">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Current Address Proof</h4> <hr>
              <div class="row">
                <div class="col-md-12">
                  <p>Please note that disbursement of payments for tutoring services provided, for example, tutoring sessions taken, content submission articles, quizzes, etc. will be done only after a valid current address proof is submitted at Eduzyte.</p>  
                </div>
              </div>  
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn" data-dismiss="modal">OK</button> 
      </div>
    </div>
  </div>
</div>