<?php include 'includes/header.php';?>

<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">    
    <div id="overlay"></div>
    <div class="img"></div>    
    <div class="subbgheader">
    	<h2>FAQ's</h2>
    </div>
</section>
 <!-- frequently asked questions area start -->
        <section id="faq-area" class="ptb-60">
            <div class="container">
            	<div class="row">
            		<div class="col-md-8 col-md-offset-2 faqsearch pb-30">
            			<div class="input-group">
            				<input type="search" name="" class="form-control input-lg" placeholder="Type A Question and Press enter!">
            				<div class="input-group-btn">
            					<button type="submit" class="btn btn-warning"><i class="fa fa-search"></i> Search</button>
            				</div>
            			</div>
            		</div>
            	</div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="section-heading text-center">
                            <h2>FAQs For Tutors</h2>                          
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-3 col-md-3 faqleftlist faqleftlist-md-20">
                        <a href="faqs.php" class="btn btn-primary">Tutor</a> <br>
                        <a href="faqs_student.php" class="btn btn-primary">Student</a>
                    </div>
                    <div class="col-sm-9 col-md-9 p-0">                        
                        <div class="faq-content-wrapper">                        	
                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="false">
                                <div class="panel">
                                    <div class="panel-heading" role="tab" id="headingOne">
                                        <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne" class="collapsed">Eduzyte</a>
                                    </h4>
                                    </div>
                                    <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                        <div class="panel-body">
                                             <div class="panel-group" id="accordion1">
                                            	<div class="panel">
				                                    <div class="panel-heading" role="tab" id="headingOne">
				                                        <h4 class="panel-title">
				                                        <a role="button" data-toggle="collapse" data-parent="#accordion1" href="#subcollapseOne" aria-expanded="true" aria-controls="collapseOne" class="collapsed">Explain Eduzyte quickly.</a>
				                                    </h4>
				                                    </div>
				                                    <div id="subcollapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
				                                        <div class="panel-body">
				                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
				                                        </div>
				                                    </div>
				                                </div>
				                                <div class="panel">
				                                    <div class="panel-heading" role="tab" id="headingOne">
				                                        <h4 class="panel-title">
				                                        <a role="button" data-toggle="collapse" data-parent="#accordion1" href="#subcollapseTwo" aria-expanded="true" aria-controls="collapseOne" class="collapsed">What is Live Online Tutoring?</a>
				                                    </h4>
				                                    </div>
				                                    <div id="subcollapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
				                                        <div class="panel-body">
				                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
				                                        </div>
				                                    </div>
				                                </div>
				                                <div class="panel">
				                                  <div class="panel-heading" role="tab" id="headingOne">
				                                      <h4 class="panel-title">
				                                      <a role="button" data-toggle="collapse" data-parent="#accordion1" href="#subcollapseThree" aria-expanded="true" aria-controls="collapseOne" class="collapsed">How many students are there in Eduzyte class at a time?</a>
				                                  </h4>
				                                  </div>
				                                  <div id="subcollapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
				                                      <div class="panel-body">
				                                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
				                                      </div>
				                                  </div>
				                              </div>
				                              <div class="panel">
				                                  <div class="panel-heading" role="tab" id="headingOne">
				                                      <h4 class="panel-title">
				                                      <a role="button" data-toggle="collapse" data-parent="#accordion1" href="#subcollapseFour" aria-expanded="true" aria-controls="collapseOne" class="collapsed">Does Eduzyte provides recorded videos?</a>
				                                  </h4>
				                                  </div>
				                                  <div id="subcollapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
				                                      <div class="panel-body">
				                                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
				                                      </div>
				                                  </div>
				                              </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel">
                                    <div class="panel-heading" role="tab" id="headingTwo">
                                        <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo" class="collapsed">Tempor inccsetetur aliquatraiy?</a>
                                    </h4>
                                    </div>
                                    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                        <div class="panel-body">
                                           
                                             <div class="panel-group" id="accordion2">
                                                <div class="panel">
                                                    <div class="panel-heading" role="tab" id="headingOne">
                                                        <h4 class="panel-title">
                                                        <a role="button" data-toggle="collapse" data-parent="#accordion2" href="#thrirdcollapseOne" aria-expanded="true" aria-controls="collapseOne" class="collapsed">Explain Eduzyte quickly.</a>
                                                    </h4>
                                                    </div>
                                                    <div id="thrirdcollapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                                        <div class="panel-body">
                                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel">
                                                    <div class="panel-heading" role="tab" id="headingOne">
                                                        <h4 class="panel-title">
                                                        <a role="button" data-toggle="collapse" data-parent="#accordion2" href="#thrirdcollapseTwo" aria-expanded="true" aria-controls="collapseOne" class="collapsed">What is Live Online Tutoring?</a>
                                                    </h4>
                                                    </div>
                                                    <div id="thrirdcollapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                                        <div class="panel-body">
                                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel">
                                                  <div class="panel-heading" role="tab" id="headingOne">
                                                      <h4 class="panel-title">
                                                      <a role="button" data-toggle="collapse" data-parent="#accordion2" href="#thrirdcollapseThree" aria-expanded="true" aria-controls="collapseOne" class="collapsed">How many students are there in Eduzyte class at a time?</a>
                                                  </h4>
                                                  </div>
                                                  <div id="thrirdcollapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                                      <div class="panel-body">
                                                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
                                                      </div>
                                                  </div>
                                              </div>
                                              <div class="panel">
                                                  <div class="panel-heading" role="tab" id="headingOne">
                                                      <h4 class="panel-title">
                                                      <a role="button" data-toggle="collapse" data-parent="#accordion2" href="#thrirdcollapseFour" aria-expanded="true" aria-controls="collapseOne" class="collapsed">Does Eduzyte provides recorded videos?</a>
                                                  </h4>
                                                  </div>
                                                  <div id="thrirdcollapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                                      <div class="panel-body">
                                                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
                                                      </div>
                                                  </div>
                                              </div>
                                            </div>
                                        
                                        </div>
                                    </div>
                                </div>
                                <div class="panel">
                                    <div class="panel-heading" role="tab" id="headingThree">
                                        <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree" class="collapsed">Tempor inccsetetur aliquatraiy?</a>
                                    </h4>
                                    </div>
                                    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                        <div class="panel-body">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel">
                                    <div class="panel-heading" role="tab" id="headingFour">
                                        <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="true" aria-controls="collapseFour" class="collapsed">Consectetur adipisicing elit, sed do eiusmod tempor?</a>
                                    </h4>
                                    </div>
                                    <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
                                        <div class="panel-body">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- frequently asked questions area end -->
<?php include 'includes/footer.php';?>