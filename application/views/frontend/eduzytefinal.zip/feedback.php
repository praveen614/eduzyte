<?php include 'includes/header.php';?>

<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">    
    <div id="overlay"></div>
    <div class="img"></div>    
    <div class="subbgheader">
    	<h2>Feedback</h2>
    </div>
</section>
        <section class="ptb-60 careers">
            <div class="container">               
            	<div class="row">
                    <div class="col-md-12">
                        <p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                        <h5>All these efforts include but are not limited to:</h5>
                        <ul>
                            <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</li>
                            <li> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</li>
                            <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</li>
                            <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</li>
                        </ul>
                        <p class="text-justify"><strong>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facere accusamus magni voluptates, iste illo doloribus consequatur aliquid laborum ratione a reiciendis eos, ab recusandae sunt libero cupiditate aspernatur totam enim!</strong></p>
                        <h5 class="blucol">Please comment on the navigability of the website? Are you able to find things which you are looking for? Please give suggestions on how to make it better?</h5>
                        <textarea rows="5" cols="10" class="form-control mb-20" placeholder="Write a Notes"></textarea>
                        <h5 class="blucol">Please comment on the design of the website? Are the colors pleasing to the eye? Is content placed in right places in right fashion? How can we make it better? </h5>
                        <textarea rows="5" cols="10" class="form-control mb-20" placeholder="Write a Notes"></textarea>
                        <h5 class="blucol">Please comment on the security considerations and any loopholes which we should be aware of. All the invaluable information which we hold can be exploited for not-so-good purposes and we intend to do everything in our power to avoid it.</h5>
                        <textarea rows="5" cols="10" class="form-control mb-20" placeholder="Write a Notes"></textarea>
                         <h5 class="blucol">Any other comments. Any issues which we should know about. </h5>
                        <textarea rows="5" cols="10" class="form-control mb-20" placeholder="Write a Notes"></textarea>
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1">
                                <div class="well">
                                    <div class="row">
                                        <div class="col-md-6">
                                <div class="form-group">
                                    <label>Full Name</label>
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-user"></i></div>
                                        <input type="text" name="" class="form-control input-lg" placeholder="Full Name">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Email</label>
                                    <div class="input-group">
                                        <div class="input-group-addon"><i class="fa fa-envelope"></i></div>
                                        <input type="text" name="" class="form-control input-lg" placeholder="Email">
                                    </div>
                                </div>
                            </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div align="center">
                            <input type="SUBMIT" name="" class="btn btn-primary" value="SUBMIT">
                        </div>
                    </div>
                </div>                                
            </div>
        </section>
<?php include 'includes/footer.php';?>