<?php include 'includes/header.php';?>
<div id="loading">
      <div id="loading-center">
        <div id="loading-center-absolute">
          <img src="img/loader.gif" alt="eduzyte">  
        </div>
      </div>
    </div>
<!-- slider area start -->
<style>
#chartdiv {
width: 100%;
height: 500px;
}
</style>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
    <div id="overlay"></div>
    <div class="img"></div>
    <div class="dots">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
    </div>
      <script>
  $( function() {
    var availableTags = [
      "IIT Jee",
      "Jee",
      "TOFEL",
      "BTech",
      "B.Sc.",
      "M.Sc.",
      "MTech",
      "JAVA",
      "C",
      "C++",
      "CAT",
      "CBSE",
      "ICSE",
      "Java",
      "JavaScript",
      "Maths",
      "Science",
      "Social",
      "English",
      "Environmental Studies"
    ];
    $( "#tags" ).autocomplete({
      source: availableTags
    });
  } );
  </script>
    <div class="mysearch">
        
        <h1>Welcome to Eduzyte</h1>
        <h3>Live Online Tutoring by Professional Tutors</h3>
        <div class="subscribe-box">
            <div id="typeit">Click here and search by subject or exam...<span></span></div>
            <form class="subscription-form " method="POST" action="">
                <div class="ui-widget"><input id="tags" class="form-control searchinput"  name="subscribe-input"></div>
                <button class="email-submit-btn" type="submit"><i class="icofont icofont-paper-plane"></i></button>
            </form>
        </div>
        
    </div>
    
    
</section>
<section>
    <div class="container-fluid frqsearch">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p>Frequently Searched: 
                        <a href="">Maths for IIT JEE-2017</a> | 
                        <a href="">Chemistry for IIT JEE-2017</a> | 
                        <a href="">Reading for SAT</a> | 
                        <a href="">QA for CAT-2017</a> | 
                        <a href="">Maths for CBSE Class-XII</a> | 
                        <a href="">Science for CBSE Class-X</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- slider area end -->
<!-- app features area start -->
<section id="app-features-area" class=" pt-20">
    <div class="container">
        <h3 class="text-muted" style="color: #47a545;">
        <div class="row">
            <div class="col-sm-4 p-0 wow fadeIn" data-wow-duration="2s">
                <div class="single-feature media">
                    <div class="feature-icon media-left">
                        <img src="img/i1.svg" alt="" width="70">
                    </div>
                    <div class="feature-details media-body">
                        <h6>Live</h6>
                        <p>Instead of physically visiting the student's home, tutors use a good Internet connection, virtual blackboard, webcam and a microphone to teach. The teacher-student interaction is two-way.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 p-0 wow fadeIn" data-wow-duration="2s" data-wow-delay="0.3s">
                <div class="single-feature media">
                    <div class="feature-icon media-left">
                        <img src="img/i2.svg" alt="" width="70">
                    </div>
                    <div class="feature-details media-body">
                        <h6>Learn</h6>
                        <p>Location no longer limits your education options. Using our online platform, you can find and use subject experts from across the World</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 p-0 wow fadeIn" data-wow-duration="2s" data-wow-delay="0.6s">
                <div class="single-feature media">
                    <div class="feature-icon media-left">
                        <img src="img/i3.svg" alt="" width="70">
                    </div>
                    <div class="feature-details media-body">
                        <h6>Grow</h6>
                        <p>Reach your goals faster with private, 1–to–1 lessons,1-Group lessons. We will help you grow up on your aims which was trained as per your requirement(s).    </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- app features area end -->
<!-- how it work area start -->
<section id="how-it-works-area" class="ptb-80">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="section-heading text-center">
                    <h2>HOW DOES IT WORK?</h2>
                    <p>The largest online hub of tutors is made up of hundreds of teachers, academics and university students</p>
                    <p>Eduzyte is the engine that connects students with tutors. We look after all your needs, from finding a tutor, scheduling a lesson, right through to use of our online classroom and payment.</p>
                    <p>Just follow 5 Easy steps to hire an Online Tutor at Eduzyte</p>
                </div>
            </div>
        </div>
        <section id="cd-timeline" class="cd-container">
            <div class="cd-timeline-block">
                <div class="cd-timeline-img cd-picture">
                    <i class=" fa fa-send"></i>
                    </div> <!-- cd-timeline-img -->
                    <div class="cd-timeline-content wow fadeInLeft">
                        <div class="media">
                            <a class="pull-left" href="#">
                                <div class="bigl"> 01</div>
                            </a>
                            <div class="media-body">
                                <h2>Post your Requirements</h2>
                                <p>Select Exam and Subject. Simply click to choose & fill the form to help us understand your tutoring need</p>
                            </div>
                        </div>
                        
                        <!--        <span class="cd-date">Step 01</span> -->
                        </div> <!-- cd-timeline-content -->
                        </div> <!-- cd-timeline-block -->
                        <div class="cd-timeline-block">
                            <div class="cd-timeline-img cd-movie">
                                <i class=" fa fa-user"></i>
                                </div> <!-- cd-timeline-img -->
                                <div class="cd-timeline-content wow fadeInRight">
                                    <div class="media">
                                        <a class="pull-left" href="#">
                                            <div class="bigl">02</div>
                                        </a>
                                        <div class="media-body">
                                            <h2>Select from Matching Tutors</h2>
                                            <p>Meet with the expert of your choice, anywhere in the world</p>
                                        </div>
                                    </div>
                                    
                                    <!--           <span class="cd-date">Step 02</span> -->
                                    </div> <!-- cd-timeline-content -->
                                    </div> <!-- cd-timeline-block -->
                                    <div class="cd-timeline-block">
                                        <div class="cd-timeline-img cd-picture">
                                            <i class=" fa fa-calendar"></i>
                                            </div> <!-- cd-timeline-img -->
                                            <div class="cd-timeline-content wow fadeInLeft">
                                                <div class="media">
                                                    <a class="pull-left" href="#">
                                                        <div class="bigl">03</div>
                                                    </a>
                                                    <div class="media-body">
                                                        <h2>Schedule </h2>
                                                        <p>Interact with the tutor & understand your child’s current preparation level via Live chat.</p>
                                                    </div>
                                                </div>
                                                
                                                <!--    <span class="cd-date">Step 03</span> -->
                                                </div> <!-- cd-timeline-content -->
                                                </div> <!-- cd-timeline-block -->
                                                <div class="cd-timeline-block">
                                                    <div class="cd-timeline-img cd-location">
                                                        <i class=" fa fa-credit-card"></i>
                                                        </div> <!-- cd-timeline-img -->
                                                        <div class="cd-timeline-content wow fadeInRight">
                                                            <div class="media">
                                                                <a class="pull-left" href="#">
                                                                    <div class="bigl">04</div>
                                                                </a>
                                                                <div class="media-body">
                                                                    <h2>Pre-pay</h2>
                                                                    <p>With Eduzyte, you buy minutes of learning time on a Pay As You Go basis. Simply, top up the minutes in your account before your lesson
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            
                                                            <!--       <span class="cd-date">Step 04</span> -->
                                                            </div> <!-- cd-timeline-content -->
                                                            </div> <!-- cd-timeline-block -->
                                                            <div class="cd-timeline-block">
                                                                <div class="cd-timeline-img cd-picture">
                                                                    <i class=" fa fa-play"></i>
                                                                    </div> <!-- cd-timeline-img -->
                                                                    <div class="cd-timeline-content wow fadeInLeft">
                                                                        <div class="media">
                                                                            <a class="pull-left" href="#">
                                                                                <div class="bigl">05</div>
                                                                            </a>
                                                                            <div class="media-body">
                                                                                <h2>Start your lesson </h2>
                                                                                <p>The lesson starts as soon as you are both ready. Our state-of-the-art classroom includes video, two-way whiteboard and file sharing.</p>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <!--    <span class="cd-date">Step 03</span> -->
                                                                        </div> <!-- cd-timeline-content -->
                                                                        </div> <!-- cd-timeline-block -->
                                                                    </section>
                                                                    <div class="text-center">
                                                                        <a href="search_a_tutor.php" class="btn btn-default">Find a Tutor</a>
                                                                    </div>
                                                                </div>
                                                            </section>
                                                            <!-- how it work area end -->
                                                            <!-- awesome feature area start -->
                                                            <section id="awesome-features-area" class="overlay-white ptb-80 hidden-xs">
                                                                <div class="container">
                                                                    <div class="awhcircle"></div>
                                                                    <div class="row">
                                                                        <div class="col-sm-12">
                                                                            <div class="section-heading text-center">
                                                                                <h2>eduzyte ADVANTAGE</h2>
                                                                                <h4 style="line-height: 30px;" class="text-muted">We’re here to standardising<br/> students and start personalising education</h4>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <ul class="hexgrid">
                                                                        <li>
                                                                            <div class="hex"><span></span><span></span><div class="holder">
                                                                            <div class="img" style="background: url(img/anim/animat-diamond.gif);"></div>
                                                                        <strong>Branded and Eduzyte Tutor</strong></div></div>
                                                                    </li><li>
                                                                    <div class="hex"><span></span><span></span><div class="holder">
                                                                    <div class="img" style="background: url(img/anim/animat-search.gif);"></div>
                                                                <strong>Thousands of tutors from around the world.</strong></div></div>
                                                            </li><li>
                                                            <div class="hex"><span></span><span></span><div class="holder"><div class="img" style="background: url(img/anim/animat-compass.gif);"></div><strong>Search tutors both online within your local area</strong></div></div>
                                                        </li>
                                                        <li>
                                                            <div class="hex"><span></span><span></span><div class="holder"></div></div>
                                                        </li>
                                                        <li>
                                                            <div class="hex"><span></span><span></span><div class="holder"><div class="img" style="background: url(img/anim/animat-responsive.gif);"></div><strong>Study from Comfort & Safety of Home</strong></div></div>
                                                        </li><li>
                                                        <div class="hex"><span></span><span></span><div class="holder"><div class="img" style="background: url(img/anim/animat-rocket.gif);"></div><strong>Available 24/7, Anytime to fit your schedule</strong></div></div>
                                                    </li><li>
                                                    <div class="hex"><span></span><span></span><div class="holder"><div class="img" style="background: url(img/anim/animat-pencil.gif);"></div><strong>Read feedback and ratings for tutors</strong></div></div>
                                                </li>
                                                <div class="clearfix"></div>
                                            </ul>
                                            
                                            
                                        </div>
                                    </section>
                                    <!-- awesome feature area end -->
                                    <!-- fun fact area start -->
                                    <section id="fun-fact-area" class="overlay-grad-one">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-sm-4 col-xs-6">
                                                    <div class="single-fact text-center">
                                                        <i class="fa fa-users"></i>
                                                        <h5>Tutorpreneurs</h5>
                                                        <h2 class="counter">1200</h2>
                                                    </div>
                                                </div>
                                                <div class="col-sm-4 col-xs-6">
                                                    <div class="single-fact text-center">
                                                        <i class="fa fa-clock-o"></i>
                                                        <h5>Hours of Tutoring
                                                        </h5>
                                                        <h2 class="counter">1080</h2>
                                                    </div>
                                                </div>
                                                <!--                  <div class="col-sm-3">
                                                    <div class="single-fact text-center">
                                                        <i class="icofont icofont-boy"></i>
                                                        <h5>Practice Questions
                                                        </h5>
                                                        <h2 class="counter">1170</h2>
                                                    </div>
                                                </div> -->
                                                <div class="col-sm-4">
                                                    <div class="single-fact text-center">
                                                        <i class="fa fa-th-large"></i>
                                                        <h5>Digital Content Users
                                                        </h5>
                                                        <h2 class="counter">720</h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                    <!-- fun fact area end -->
                                    <!--faqstart-->
                                    <section id="faq-area" class="pt-80 pb-30 faq-area">
            <div class="container">                
                <div class="row">
                    <div class="col-sm-12">
                        <div class="section-heading text-center">
                            <h2>FREQUENTLY ASKED QUESTIONS</h2>                          
                        </div>
                    </div>
                </div>
                <div class="row">                   
                    <div class="col-sm-12 col-md-6 p-0">
                        <div class="faq-content-wrapper homefaq" style="margin-left: 25px;">
                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="false">
                                <div class="panel clearfix">
                                    <div class="panel-heading" role="tab" id="headingOne">
                                        <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne" class="collapsed">Sedeiusmod tempor inccsetetur aliquatraiy?</a>
                                    </h4>
                                    </div>
                                    <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                        <div class="panel-body">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel">
                                    <div class="panel-heading" role="tab" id="headingTwo">
                                        <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo" class="collapsed">Sedeiusmod tempor inccsetetur aliquatraiy?</a>
                                    </h4>
                                    </div>
                                    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                        <div class="panel-body">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel">
                                    <div class="panel-heading" role="tab" id="headingThree">
                                        <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree" class="collapsed">Tempor inccsetetur aliquatraiy?</a>
                                    </h4>
                                    </div>
                                    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                        <div class="panel-body">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel">
                                    <div class="panel-heading" role="tab" id="headingFour">
                                        <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="true" aria-controls="collapseFour" class="collapsed">Consectetur adipisicing elit, sed do eiusmod tempor?</a>
                                    </h4>
                                    </div>
                                    <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
                                        <div class="panel-body">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6 p-0 smpdfaq">
                         <div class="faq-content-wrapper homefaq">
                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="false">
                                <div class="panel">
                                    <div class="panel-heading" role="tab" id="headingFive">
                                        <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="true" aria-controls="collapseFive" class="collapsed">Consectetur adipisicing elit, sed do eiusmod tempor?</a>
                                    </h4>
                                    </div>
                                    <div id="collapseFive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
                                        <div class="panel-body">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel">
                                    <div class="panel-heading" role="tab" id="headingSix">
                                        <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseSix" aria-expanded="true" aria-controls="collapseSix" class="collapsed">Consectetur adipisicing elit, sed do eiusmod tempor?</a>
                                    </h4>
                                    </div>
                                    <div id="collapseSix" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingSix">
                                        <div class="panel-body">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel">
                                    <div class="panel-heading" role="tab" id="headingSeven">
                                        <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseSeven" aria-expanded="true" aria-controls="collapseSeven" class="collapsed">Consectetur adipisicing elit, sed do eiusmod tempor?</a>
                                    </h4>
                                    </div>
                                    <div id="collapseSeven" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingSeven">
                                        <div class="panel-body">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel">
                                    <div class="panel-heading" role="tab" id="headingEight">
                                        <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseEight" aria-expanded="true" aria-controls="collapseEight" class="collapsed">Consectetur adipisicing elit, sed do eiusmod tempor?</a>
                                    </h4>
                                    </div>
                                    <div id="collapseEight" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingEight">
                                        <div class="panel-body">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporo incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrd exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute dolor in reprehenderit in voluptate velit esse cillum dolore</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                         </div>
                    </div>
                </div>
                <div class="text-center mt-40">
                   <a href="faqs.php" class="btn btn-default">More Questions?</a>
                </div>
            </div>
        </section>
                                    <!--faqsend-->
                                    <!-- testimonial area start -->
                                    <section id="testimonial-area" class="home-style-3 pt-50">
                                        <div class="container">
                                            <div class="slider-wrapper-2">
                                                <div class="slide">
                                                    <div class="row">
                                                        <div class="col-sm-12">
                                                            <div class="slider-content text-center">
                                                                <div class="client-image">
                                                                    <img src="img/clients/client-1.jpg" alt="" class="img-responsive img-circle center-block">
                                                                </div>
                                                                <div class="client-testimonial">
                                                                    <h3>JASON ADAMS</h3>
                                                                    <p class="client-designation">Faltu Designer</p>
                                                                    <p class="client-review">“Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incubt consectetur aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut com modo consequat. Duis aute irure dolor in reprehenderit.”</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="slide">
                                                    <div class="row">
                                                        <div class="col-sm-12">
                                                            <div class="slider-content text-center">
                                                                <div class="client-image">
                                                                    <img src="img/clients/client-1.jpg" alt="" class="img-responsive img-circle center-block">
                                                                </div>
                                                                <div class="client-testimonial">
                                                                    <h3>JASON ADAMS</h3>
                                                                    <p class="client-designation">Faltu Designer</p>
                                                                    <p class="client-review">“Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incubt consectetur aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut com modo consequat. Duis aute irure dolor in reprehenderit.”</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="slide">
                                                    <div class="row">
                                                        <div class="col-sm-12">
                                                            <div class="slider-content text-center">
                                                                <div class="client-image">
                                                                    <img src="img/clients/client-1.jpg" alt="" class="img-responsive img-circle center-block">
                                                                </div>
                                                                <div class="client-testimonial">
                                                                    <h3>JASON ADAMS</h3>
                                                                    <p class="client-designation">Faltu Designer</p>
                                                                    <p class="client-review">“Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incubt consectetur aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut com modo consequat. Duis aute irure dolor in reprehenderit.”</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="slide">
                                                    <div class="row">
                                                        <div class="col-sm-12">
                                                            <div class="slider-content text-center">
                                                                <div class="client-image">
                                                                    <img src="img/clients/client-1.jpg" alt="" class="img-responsive img-circle center-block">
                                                                </div>
                                                                <div class="client-testimonial">
                                                                    <h3>JASON ADAMS</h3>
                                                                    <p class="client-designation">Faltu Designer</p>
                                                                    <p class="client-review">“Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incubt consectetur aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut com modo consequat. Duis aute irure dolor in reprehenderit.”</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                    <!-- testimonial area end -->                                    
                                    <!-- app download area start -->
                                    <!-- <section id="app-download-area" class="blue-grad-bg ptb-100" >
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-sm-7">
                                                    <div class="download-app">
                                                        <h1>Download eduzyte </h1>
                                                        <p>Lorem ipsum madolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor coli incididunt ut labore Lorem ipsum madolor sit amet, consectetur adipisicing incididunt.</p>
                                                        <div class="button-group store-buttons">
                                                            <a href="#" class="btn btn-bordered-white">
                                                                <i class="icofont icofont-brand-android-robot dsp-tc"></i>
                                                                <p class="dsp-tc">available on
                                                                    <br> <span>Google Store</span></p>
                                                                </a>
                                                                <a href="#" class="btn btn-bordered-white">
                                                                    <i class="icofont icofont-brand-apple dsp-tc"></i>
                                                                    <p class="dsp-tc">available on
                                                                        <br> <span>Apple Store</span></p>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </section> -->
                                            <!-- app download area end -->         
                                            <script>
                                                <?php
                                                    if(isset($_GET['loc'])){
                                                ?>
                                                $('html, body').animate({
                                                    scrollTop: ($("#how-it-works-area").offset().top-100)
                                                }, 2000);
                                                <?php        
                                                    }
                                                ?>
                                            </script>           
                                            <section id="app-about-area" class=" gray-bg pt-40">
    <div class="container">
       <p>Eduzyte has provided tutoring for thousands of students all over the globe. Research has shown that the greatest impact on learning is the quality and experience of the instructor. Eduzyte tutors only highly qualified, full-time tutors who receive weekly, professional development.</p>
        <p>Eduzyte’s convenient online platform is preferred by students and optimizes the learning experience through ease of scheduling and access to top-quality tutors anywhere, at any time. Because it fits easily with a student’s schedule, the platform ensures consistent use and, therefore, exceptional results.</p>
        <p>Eduzyte’s convenient online tutoring services optimize the learning experience with engaging tutoring, ease of scheduling and top-quality tutors anywhere, at any time. We customize our tutoring to easily fit a student’s schedule and provide exceptional results.</p>
    </div>
    </section>                      
                                                                                                                           
<!-- map area end -->
    <?php include 'includes/footer.php'?>