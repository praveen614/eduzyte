<?php include 'includes/header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>TEACHING DETAILS</h2>
  </div>
</section>
<section id="how-it-works-area" class="ptb-60">
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-md-offset-1 profstep">
        <div class="about-app mt-0 single-widget">
          <div class="progress mtmb-20">
          <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 85%">
            Page 4/5
          </div>
        </div>
        <div class="alert alert-success alert-dismissible fade in mb-20" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
            <i class="fa fa-check-circle fa-lg"></i> Education Qualification Updated
          </div> 
         <form action="profile_teaching_time_slot_details_step.php">
          <div class="col-md-6">
            <label>Teaching Expertise <span class="txt_red">*</span></label>
            <div class="form-group">
              <input type="text" class="form-control input-lg" placeholder="Teaching Expertise" required>
            </div>            
          </div> 
          <div class="col-md-6">
            <label>Medium Of Instruction <span class="txt_red">*</span></label>
            <div class="form-group">
              <select class="form-control input-lg seexam">
                <option>-Select-</option>                 
                <option>English Medium</option>
                <option>Telugu Medium</option>
              </select>
            </div> 
            <p><a href="#addMedium" class="blulink" data-toggle="modal">If not in options in above, add a new medium</a></p>           
          </div>
          <div class="col-md-6">
                <label>Total Teaching Experience (offline+online, in Years) <span class="txt_red">*</span></label>
                <div class="form-group">
                  <input type="number" class="form-control input-lg mx150" required min="1" max="50" placeholder="1">
                </div>
              </div>
              <div class="col-md-6">
                <label>Online Teaching Experience (In Years) <span class="txt_red">*</span></label>
                <div class="form-group">
                  <input type="number" class="form-control input-lg mx150" required min="1" max="50" placeholder="1">
                </div>
              </div>
          <div class="col-md-3">
            <label>Do you have a digital Pen? <span class="txt_red">*</span></label> <br>
            <div class="form-group">
              <input type="radio" name="dgpen" data-toggle="modal" data-target="#digitalModal"> Yes
              <input type="radio" name="dgpen" > No
            </div>
          </div>
          <div class="col-md-3">
            <label>Do you have a digital Slate? <span class="txt_red">*</span></label> <br>
            <div class="form-group">
              <input type="radio" name="dgslt"> Yes
              <input type="radio" name="dgslt" > No
            </div>
          </div>
          <div class="col-md-6">
            <label>Are you currently a full time teacher employed by a School/College <span class="txt_red">*</span></label> <br>
            <div class="form-group">
              <input type="radio" name="" checked> Yes
              <input type="radio" name="" > No
            </div>
          </div>
          <div class="col-md-6">
            <label>Opportunities you are interested in <span class="txt_red">*</span></label> <br>
            <div class="form-group">
              <select class="form-control input-lg seexam">
                <option>Full Time</option>                 
                <option>Part Time</option>
                <option>Both (Full Time & Part Time)</option>
              </select>
            </div>
          </div>
          <div class="col-md-6">
            <label>Expecting hourly Pricing <span class="txt_red">*</span></label>
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-addon">$</div>
                <input type="text" name="" class="form-control input-lg">
              </div>
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="col-md-12">
            <label>Teaching Approach <span class="txt_red">*</span></label>
            <div class="form-group">
              <textarea name="" rows="5" cols="10" class="form-control" placeholder="Description should be 100 minimum words"></textarea>
            </div>
          </div>
          <div class="col-md-12">
            <div class="form-group">
              <input type="checkbox" name=""> I have not shared any contact details (Email, Phone, Skype, Website etc)
            </div>
          </div>
          <div class="col-md-12">
            <div class="form-group">
              <a href="<?=$_SERVER['HTTP_REFERER']?>" class="btn pull-left" ><i class="icofont icofont-simple-left"></i> BACK</a>

              <button type="submit" class="btn pull-right mg-20 res-mt-10"> GO To NEXT STEP</button>
        <button type="submit" class="btn pull-right res-mt-10"><i class="icofont icofont-save"></i> SAVE</button>


      </div>
          </div>
         </form>
       
        </div>
      </div>
    </div>
  </div>
</section>
<!-- app about area start -->
<?php include 'includes/footer.php';?>
<!-- Modal -->
<div class="modal fade bs-example-modal-lg" id="digitalModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">     
      <div class="modal-body forgot">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">PEN TABLET/GRAPHIC TABLET</h4> <hr>
              <div class="row">
                <div class="col-md-6">
                  <h4>What is a pen tablet/graphic tablet?</h4>
                  <p>A pen tablet/graphic tablet is a device that allows users to write/draw on computer screen without using a mouse or keyboard. It has a USB connection, that allows users to connect it to their computer.</p>
                  <h4>How it works?</h4>
                  <p>It allows users to write or draw images/ graphics similar to the way a person writes or draws with a pencil/pen on paper.</p>
                  <h4>Why is it required?</h4>
                  <p>Tutors can write on white board in virtual classroom in their own handwriting using pen/graphic tablet. It saves time make sessions more interactive.</p>
                </div>
                <div class="col-md-6">
                  <img src="img/digitaltablet.jpg" alt="" class="img-responsive">
                </div>
              </div>  
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn" data-dismiss="modal">CLOSE</button> 
      </div>
    </div>
  </div>
</div>
<!-- Modal -->
<div class="modal fade" id="addMedium" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">     
      <div class="modal-body forgot">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Add Medium Of Instruction</h4> <hr>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label><strong>Medium Name</strong></label><br>                   
                <div class="input-group">
                  <div class="input-group-addon"><i class="fa fa-sticky-note-o fa-lg"></i></div>
                  <input type="text" class="form-control input-lg" placeholder="Add Medium">
                </div>
                 <small class="text-danger text-center"><strong>Please add only one Medium at a time.</strong></small>
              </div>    <hr>          
              <div class="form-group text-center">                
                <button type="submit" class="btn"><i class="icofont icofont-paper-plane"></i> SAVE</button> 
                <button type="submit" class="btn" data-dismiss="modal"><i class="icofont icofont-close"></i> CANCEL</button> 
              </div> 
                </div>
              </div>                             
                
      </div>
    </div>
  </div>
</div>
<script>
  $(function () {
   $('[data-toggle="tooltip"]').tooltip()
})
</script>