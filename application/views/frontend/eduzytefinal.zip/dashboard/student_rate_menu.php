<div class="left-sidebar">
    <aside class="single-widget dashboard-side-menu">
        <h6 class="widget-title">Performance Menu</h6>
        <div class="widget-content categories-widget">
            <ul>
                <li <?php if ($page == 'rate_your_student.php') { ?>class="active"<?php } ?>><a href="rate_your_student.php">Rate Your Student</a></li>
                <li <?php if ($page == 'ratings_by_student.php') { ?>class="active"<?php } ?>><a href="ratings_by_student.php">Ratings By Student</a></li>
            </ul>
        </div>
    </aside>
</div>