<?php include 'includes/dashboard_header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>MY DASHBOARD</h2>
  </div>
</section>
<section id="app-about-area" class="ptb-30 dashboard">
  <div class="container">  
        <div class="about-app mt-0">
          <?php include 'tutor_welcome.php';?>
          <div class="row">
            <div class="col-md-3">
                  <?php include 'messages_menu.php';?>
            </div>
            <div class="col-md-9">
               <?php include 'dashboard_tabmenu.php';?>
               <form class="form-horizontal mt-20 profstep">
                  <div class="form-group">
                    <label class="col-sm-2 control-label">To: </label>
                    <div class="col-sm-10">
                      <select name="" id="" class="form-control input-lg seexam">
                        <option value="">Choose Student</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">Subject:</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control input-lg">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">Message:</label>
                    <div class="col-sm-10">
                      <textarea name="" id="" cols="30" rows="5" class="form-control"></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <button class="btn btn-primary pull-right" type="submit">Send Message</button>
                  </div>
               </form>
               <div class="row">
            <div class="col-md-12">
              <div class="alert alert-danger text-center">
                    <strong>Note:</strong> All the messages will be delivered to the tutors after approved by Eduzyte admin and if messages contains any inappropriate words, contact details will not be delivered and same will be displayed on ‘Rejected Mails’
                  </div>
            </div>
          </div>
            </div>
          </div>
        </div>
  </div>
</section>                                       
<?php include 'includes/dashboard_footer.php';?>