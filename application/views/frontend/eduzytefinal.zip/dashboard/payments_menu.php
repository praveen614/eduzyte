<div class="left-sidebar">
    <aside class="single-widget dashboard-side-menu">
        <h6 class="widget-title">Payments Menu</h6>
        <div class="widget-content categories-widget">
            <ul>
                <li <?php if ($page == 'tutor_payments.php') { ?>class="active"<?php } ?>><a href="tutor_payments.php">Make Payment</a></li>
                <li <?php if ($page == 'tutor_payments_referrals.php') { ?>class="active"<?php } ?>><a href="tutor_payments_referrals.php">View Referral Credit </a></li>
            </ul>
        </div>
    </aside>
</div>