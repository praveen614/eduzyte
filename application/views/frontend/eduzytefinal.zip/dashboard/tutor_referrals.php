<?php include 'includes/dashboard_header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>MY DASHBOARD</h2>
  </div>
</section>
<section id="app-about-area" class="ptb-30 dashboard profstep persform">
  <div class="container">  
        <div class="about-app mt-0">
          <?php include 'tutor_welcome.php';?>
          <div class="row">
            <div class="col-md-3">
                  <?php include 'referrals_menu.php';?>
            </div>
            <div class="col-md-9">
               <?php include 'dashboard_tabmenu.php';?>
               <div class="mt10">
                 <h4 class="blutxt">Your friend's details <small>(The student you are referring to Spanedea)</small></h4> <hr>
                 <form class="form-horizontal mt-20 profstep">
                    <div class="form-group">
                    <label class="col-sm-2 control-label">Name <span class="red">*</span> </label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control input-lg" placeholder="Name of Student">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">Email ID <span class="red">*</span> </label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control input-lg" placeholder="Email ID of student">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">Mobile Number <span class="red">*</span> </label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control input-lg" placeholder="Mobile Number of Student">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">Requirement <span class="red">*</span> </label>
                    <div class="col-sm-10">
                      <select class="form-control input-lg seexam">
                          <option value="">Select Exam</option>
                          <option value='IIT JEE' >IIT JEE</option>
                          <option value='BITSAT' >BITSAT</option>
                          <option value='PMT' >PMT</option>
                          <option value='SAT' >SAT</option>
                          <option value='GRE' >GRE</option>
                          <option value='GMAT' >GMAT</option>
                          <option value='TOEFL' >TOEFL</option>
                          <option value='CAT' >CAT</option>
                          <option value='OTHERS' >OTHERS</option>
                      </select>
                    </div>
                  </div>
                  <h4 class="blutxt">Parent details <small>(Mandatory if student is below 18 years of age)</small></h4> <hr>
                  <div class="form-group">
                   <label class="col-sm-2 control-label">Parent's Name <span class="red">*</span> </label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control input-lg" placeholder="Name of either mother or father">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">Parent's Email ID <span class="red">*</span> </label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control input-lg" placeholder="Email ID either mother or father">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">Parent's Mobile <span class="red">*</span> </label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control input-lg" placeholder="Mobile Number either mother or father">
                    </div>
                  </div>
                  <hr>
                  <button class="btn btn-primary pull-right" type="submit"><i class="fa fa-plus-circle"></i> Add Student Details</button>
                 </form>
               </div>
            </div>
          </div>
        </div>
  </div>
</section>                                       
<?php include 'includes/dashboard_footer.php';?>