<?php include 'includes/dashboard_header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>MY DASHBOARD</h2>
  </div>
</section>
<section id="app-about-area" class="ptb-30 dashboard profstep persform">
  <div class="container">  
        <div class="about-app mt-0">
          <?php include 'tutor_welcome.php';?>
          <div class="row">
            <div class="col-md-3">
                  <?php include 'referrals_menu.php';?>
            </div>
            <div class="col-md-9">
               <?php include 'dashboard_tabmenu.php';?>
               <div id="no-more-tables" class="sr-view">
                  <table class="table table-bordered table-striped table-responsive cf mt-20">
                    <thead class="cf">
                      <tr>
                        <th>Student Name</th>  
                        <th>Student Contact Details</th>   
                        <th>Eduzyte credits (in INR)</th>   
                        <th>Classes Taken</th>   
                        <th>Referred on</th>
                      </tr>
                    </thead>
                    <tr>
                      <td data-title="Student Name">Kumar</td>
                      <td data-title="Student Contact Details">12346579</td>
                      <td data-title="Eduzyte credits (in INR)"><i class="fa fa-rupee"></i> 1000/-</td>
                      <td data-title="Classes Taken">lorem ipsum</td>
                      <td data-title="Referred on">Pradeep</td>
                    </tr>
                  </table>
               </div>
               <div class="alert alert-success text-center">
                 You have not referred anybody yet. <a href="tutor_referrals.php">Refer now</a>
               </div>
            </div>
          </div>
        </div>
  </div>
</section>                                       
<?php include 'includes/dashboard_footer.php';?>