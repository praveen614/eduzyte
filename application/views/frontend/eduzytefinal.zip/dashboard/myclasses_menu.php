<div class="left-sidebar">
    <aside class="single-widget dashboard-side-menu">
        <h6 class="widget-title">My Classes Menu</h6>
        <div class="widget-content categories-widget">
            <ul>
                <li <?php if ($page == 'tutor_dashboard.php') { ?>class="active"<?php } ?>><a href="tutor_dashboard.php">Start Class</a></li>
                <li <?php if ($page == 'tutor_classes_schduled.php') { ?>class="active"<?php } ?>><a href="tutor_classes_schduled.php">Scheduled Classes</a></li>
                <li <?php if ($page == 'tutor_classes_completed.php') { ?>class="active"<?php } ?>><a href="tutor_classes_completed.php">Completed Classes</a></li>
            </ul>
        </div>
    </aside>
</div>