<?php include 'includes/dashboard_header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>MY DASHBOARD</h2>
  </div>
</section>
<section id="app-about-area" class="ptb-30 dashboard profstep persform">
  <div class="container">  
        <div class="about-app mt-0">
          <?php include 'tutor_welcome.php';?>
          <div class="row">
            <div class="col-md-3">
                  <?php include 'referrals_menu.php';?>
            </div>
            <div class="col-md-9">
               <?php include 'dashboard_tabmenu.php';?>
               <div id="no-more-tables" class="sr-view">
                  <table class="table table-bordered table-striped table-responsive cf mt-20">
                    <thead class="cf">
                      <tr>
                        <th>Scheme ID</th>   
                        <th>Valid From</th>  
                        <th>Valid Till</th>  
                        <th>Reward Amount</th>   
                        <th>Get Reward When</th>
                      </tr>
                    </thead>
                    <tr>
                      <td data-title="Scheme ID">SCH-2</td>
                      <td data-title="Valid From">15th May, 2015</td>
                      <td data-title="Valid Till">30th June, 2015</td>
                      <td data-title="Reward Amount"><i class="fa fa-rupee"></i> 5000/-</td>
                      <td data-title="Get Reward When">Student completes their paid classes.</td>
                    </tr>
                  </table>
               </div>
               <div class="alert alert-info text-center">
                 <h4 class="text-left">How it works?</h4>
                 <p>Refer a student to Eduzyte. A classmate, a junior, a friend or even your sibling, older or younger. Student enrolls with a Eduzyte tutor and starts taking paid classes and Eduzyte rewards you for your good deed!</p>
               </div>
            </div>
          </div>
        </div>
  </div>
</section>                                       
<?php include 'includes/dashboard_footer.php';?>