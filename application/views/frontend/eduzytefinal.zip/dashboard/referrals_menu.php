<div class="left-sidebar">
    <aside class="single-widget dashboard-side-menu">
        <h6 class="widget-title">Referrals Menu</h6>
        <div class="widget-content categories-widget">
            <ul>
                <li <?php if ($page == 'tutor_referrals.php') { ?>class="active"<?php } ?>><a href="tutor_referrals.php">Refer a Student</a></li>
                <li <?php if ($page == 'tutor_view_reffered.php') { ?>class="active"<?php } ?>><a href="tutor_view_reffered.php">View Referred Students </a></li>
                <li <?php if ($page == 'tutor_view_schemes.php') { ?>class="active"<?php } ?>><a href="tutor_view_schemes.php">View Schemes </a></li>
            </ul>
        </div>
    </aside>
</div>