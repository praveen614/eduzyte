<?php include 'includes/dashboard_header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>MY DASHBOARD</h2>
  </div>
</section>
<section id="app-about-area" class="ptb-30 dashboard">
  <div class="container">  
        <div class="about-app mt-0">
          <?php include 'tutor_welcome.php';?>
          <div class="row">
            <div class="col-md-3">
                  <?php include 'myclasses_menu.php';?>
            </div>
            <div class="col-md-9">
               <?php include 'dashboard_tabmenu.php';?>
               <div id="no-more-tables" class="sr-view">
                  <table class="table table-bordered table-striped table-responsive cf mt-20">
                    <thead class="cf">
                      <tr>
                        <th>Tutor Name</th>
                        <th>Requested Class Time (IST)</th>
                        <th>Requested Class Duration (mins)</th>
                        <th>Request Origin Time</th>
                        <th>Request Lapse Time</th>
                      </tr>
                    </thead>
                    <tr>
                      <td data-title="Tutor Name">Monohar Kumar</td>
                      <td data-title="Requested Class Time (IST)">10-Jan-2018, 06:30 PM.</td>
                      <td data-title="Requested Class Duration (mins)">2 Hours</td>
                      <td data-title="Request Origin Time">2 Hours</td>
                      <td data-title="Request Lapse Time">9:30 PM</td>
                    </tr>
                  </table>
               </div>
            </div>
          </div>
        </div>
  </div>
</section>                                       
<?php include 'includes/dashboard_footer.php';?>