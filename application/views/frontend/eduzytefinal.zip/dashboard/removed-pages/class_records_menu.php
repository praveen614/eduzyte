<div class="left-sidebar">
    <aside class="single-widget dashboard-side-menu">
        <h6 class="widget-title">Class Records Menu</h6>
        <div class="widget-content categories-widget">
            <ul>
                <li <?php if ($page == 'tutor_class_records_completed.php') { ?>class="active"<?php } ?>><a href="tutor_class_records_completed.php">Completed Classes</a></li>
                <li <?php if ($page == 'tutor_class_records_my_no_shows.php') { ?>class="active"<?php } ?>><a href="tutor_class_records_my_no_shows.php">My No-Show </a></li>
                <li <?php if ($page == 'tutor_class_records_tutor_no_shows.php') { ?>class="active"<?php } ?>><a href="tutor_class_records_tutor_no_shows.php">Tutor No-Shows </a></li>
                <li <?php if ($page == 'tutor_class_records_class_notes.php') { ?>class="active"<?php } ?>><a href="tutor_class_records_class_notes.php">Class Notes </a></li>
            </ul>
        </div>
    </aside>
</div>