<?php include 'includes/dashboard_header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>MY DASHBOARD</h2>
  </div>
</section>
<section id="app-about-area" class="ptb-30 dashboard profstep">
  <div class="container">  
        <div class="about-app mt-0">
          <?php include 'tutor_welcome.php';?>
          <div class="row">
            <div class="col-md-3">
                  <?php include 'messages_menu.php';?>
            </div>
            <div class="col-md-9">
               <?php include 'dashboard_tabmenu.php';?>
               <div class="mt-20 res-mb-10">
                 <div class="pull-right">
                 <select name="" id="" class="form-control input-lg sexam">
                   <option value="">Select an option</option>
                   <option value="">Chat with support (Eduzyte)</option>
                 </select>
               </div>
               <h5>Chat</h5>
               </div>
               <div class="row res-mt-10">
                 <div class="col-md-12">
                   <div class="well text-center fl">
                 You can chat here with your Spanedea Tutors. Do not have a tutor yet? <br>
                 <a href="#" class="btn btn-primary mt-10 mb-10">Click Here</a> 
                 <br><p class="fl">to find your best fit tutor Or Let us help with the search</p> <br>
                <a href="#" class="btn btn-primary mt-10 mb-10">Click Here for Assisted Search</a>
               </div>
                 </div>
               </div>
            </div>
          </div>
        </div>
  </div>
</section>                                       
<?php include 'includes/dashboard_footer.php';?>