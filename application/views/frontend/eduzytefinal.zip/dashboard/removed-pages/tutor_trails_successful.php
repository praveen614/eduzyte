<?php include 'includes/dashboard_header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>MY DASHBOARD</h2>
  </div>
</section>
<section id="app-about-area" class="ptb-30 dashboard">
  <div class="container">  
        <div class="about-app mt-0">
          <?php include 'tutor_welcome.php';?>
          <div class="row">
            <div class="col-md-3">
                  <?php include 'trails_menu.php';?>
            </div>
            <div class="col-md-9">
               <?php include 'dashboard_tabmenu.php';?>
               <div id="no-more-tables" class="sr-view">
                  <table class="table table-bordered table-striped table-responsive cf mt-20">
                    <thead class="cf">
                      <tr>
                        <th>Request Number</th>  
                        <th>Exam</th>  
                        <th>Program</th>   
                        <th>Tutor Name</th>  
                        <th>Trial Class Date & Time</th> 
                      </tr>
                    </thead>
                    <tr>
                      <td data-title="Request Number">001</td>
                      <td data-title="Exam">TOFEL</td>
                      <td data-title="Program">JEE</td>
                      <td data-title="Tutor Name">Kumar</td>
                      <td data-title="Trial Class Date & Time">10-jan -2018 9:30 AM</td>
                    </tr>
                  </table>
               </div>
            </div>
          </div>
        </div>
  </div>
</section>                                       
<?php include 'includes/dashboard_footer.php';?>