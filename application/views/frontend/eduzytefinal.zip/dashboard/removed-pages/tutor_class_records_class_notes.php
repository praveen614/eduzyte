<?php include 'includes/dashboard_header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>MY DASHBOARD</h2>
  </div>
</section>
<section id="app-about-area" class="ptb-30 dashboard">
  <div class="container">  
        <div class="about-app mt-0">
          <?php include 'tutor_welcome.php';?>
          <div class="row">
            <div class="col-md-3">
                  <?php include 'class_records_menu.php';?>
            </div>
            <div class="col-md-9">
               <?php include 'dashboard_tabmenu.php';?>
               <div id="no-more-tables" class="sr-view">
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped cf mt-20">
                    <thead class="cf">
                      <tr>
                         <th>Date</th>   
                         <th>Meeting ID</th>  
                         <th>Class with</th>  
                         <th>Chat messages</th>   
                         <th>Documents Received</th>  
                         <th>Whiteboard Screenshots saved</th>
                      </tr>
                    </thead>
                    <tbody>
                    <tr>
                      <td data-title="Date">Dec 29, 2017</td>
                      <td data-title="Meeting ID">Demo Meeting</td>
                      <td data-title="Class with">Applying as a tutor? <a href="#">Click Here</a></td>
                      <td data-title="Chat messages">PRADEEP : hiiii</td>
                      <td data-title="Documents Received">No Document found!</td>
                      <td data-title="Whiteboard Screenshots saved">No Screenshot found!</td>
                    </tr>  
                    </tbody>
                  </table>
                  </div>
               </div>
            </div>
          </div>
        </div>
  </div>
</section>                                       
<?php include 'includes/dashboard_footer.php';?>