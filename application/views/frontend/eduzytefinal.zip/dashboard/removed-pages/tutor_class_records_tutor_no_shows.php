<?php include 'includes/dashboard_header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>MY DASHBOARD</h2>
  </div>
</section>
<section id="app-about-area" class="ptb-30 dashboard">
  <div class="container">  
        <div class="about-app mt-0">
          <?php include 'tutor_welcome.php';?>
          <div class="row">
            <div class="col-md-3">
                  <?php include 'class_records_menu.php';?>
            </div>
            <div class="col-md-9">
               <?php include 'dashboard_tabmenu.php';?>
               <div id="no-more-tables" class="sr-view">
                  <table class="table table-bordered table-striped table-responsive cf mt-20">
                    <thead class="cf">
                      <tr>
                         <th>MID</th>   
                         <th>Tutor Name</th>  
                         <th>Scheduled Date and Time</th>   
                         <th>Duration (mins)</th>   
                         <th>Please review tutor's reasons for <br>being unable to attend scheduled class</th>
                      </tr>
                    </thead>
                    <tr>
                      <td data-title="MID">001</td>
                      <td data-title="Tutor Name">Kumar</td>
                      <td data-title="Scheduled Date and Time">10-Jan-2018 , 04 PM</td>
                      <td data-title="Duration (mins)">30 mins</td>
                      <td data-title="Please review tutor's reasons for <br>being unable to attend scheduled class">Lorem</td>
                    </tr>
                  </table>
               </div>
            </div>
          </div>
        </div>
  </div>
</section>                                       
<?php include 'includes/dashboard_footer.php';?>