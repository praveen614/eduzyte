<?php include 'includes/dashboard_header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>MY DASHBOARD</h2>
  </div>
</section>
<section id="app-about-area" class="ptb-30 dashboard">
  <div class="container">  
        <div class="about-app mt-0">
          <?php include 'tutor_welcome.php';?>
          <div class="row">
            <div class="col-md-3">
                  <?php include 'messages_menu.php';?>
            </div>
            <div class="col-md-9">
               <?php include 'dashboard_tabmenu.php';?>
               <div id="no-more-tables" class="sr-view">
                  <table class="table table-bordered table-striped table-responsive cf mt-20">
                    <thead class="cf">
                      <tr>
                        <th>Document ID</th>   
                        <th>Student Name</th>  
                        <th>Uploaded at</th>   
                        <th>Message</th>   
                        <th>Expiry</th>
                      </tr>
                    </thead>
                    <tr>
                      <td data-title="Document ID">Pradeep</td>
                      <td data-title="Student Name">Kumar</td>
                      <td data-title="Uploaded at">--</td>
                      <td data-title="Message">loremipdum</td>
                      <td data-title="Expiry">15-Dec-2018</td>
                    </tr>
                  </table>
               </div>
            </div>
          </div>
        </div>
  </div>
</section>                                       
<?php include 'includes/dashboard_footer.php';?>