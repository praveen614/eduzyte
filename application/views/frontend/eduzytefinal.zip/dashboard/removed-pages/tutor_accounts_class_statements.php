<?php include 'includes/dashboard_header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>MY DASHBOARD</h2>
  </div>
</section>
<section id="app-about-area" class="ptb-30 dashboard">
  <div class="container">  
        <div class="about-app mt-0">
          <?php include 'tutor_welcome.php';?>
          <div class="row">
            <div class="col-md-3">
                  <?php include 'accounts_menu.php';?>
            </div>
            <div class="col-md-9">
               <?php include 'dashboard_tabmenu.php';?>
               <div class="mt-20">
                 <ol class="numlist">
                  <li>Consumption (minutes recorded) starts when both tutor and student are in the class (for one-to-one classes)</li>
                  <li>In-case there were audio issues, internet connectivity problem or a class break - the tutor and/or student must inform the team immediately after the class via email (learn@eduzyte.net). The minutes will be reduced accordingly.</li>
                  <li>Once the class is 'Closed' by eduzyte system/team you will receive an email with the final minutes consumed (assume class occurred for T1 minutes).</li>
                  <li>T1 is then rounded off based on the rules (as given below) to T2. The rounded minutes T2 is the duration based on which the student fee consumed is calculated, and also the tutor is gets paid.</li>
                  <li>If the class duration is 0&#60;T1≤60: then T1 will be rounded off to the nearest 5 minutes. For eg. T1=52 is rounded off to 50 and T1=53 is rounded off to 55.></li>
                  <li>If the class duration is 60&#60;T1≤120 : then T1 will be rounded off to lowest 5 minutes. For eg. T1=68 is rounded downwards to 65.</li>
                  <li>If the class duration is 120&#60;T1: then T1 will be reduced by 5 minutes and then rounded off to lowest 5 minutes. (It will not go below 120 minutes). For eg. if T1=136, then 5 is deducted from it = 131 and then rounded downwards to 130.</li>
               </ol>
               </div>
            </div>
          </div>
        </div>
  </div>
</section>                                       
<?php include 'includes/dashboard_footer.php';?>