<?php include 'includes/dashboard_header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>MY DASHBOARD</h2>
  </div>
</section>
<section id="app-about-area" class="ptb-30 dashboard">
  <div class="container">  
        <div class="about-app mt-0">
          <?php include 'tutor_welcome.php';?>
          <div class="row">
            <div class="col-md-3">
                  <?php include 'class_records_menu.php';?>
            </div>
            <div class="col-md-9">
               <?php include 'dashboard_tabmenu.php';?>
               <div class="table-responsive">
                  <table class="table table-bordered table-striped  mt-20">
                    <thead class="cf">
                      <tr bgcolor="#05aeff" style="color: #fff;">
                         <th>MID</th>   
                         <th>Tutor Name</th>  
                         <th>Scheduled Date and Time</th>   
                         <th>Duration (mins)</th>   
                         <th>Kindly help tutor understand why you <br> were not able to attend scheduled class</th>
                      </tr>
                    </thead>
                    <tr>
                      <td>001</td>
                      <td>Kumar</td>
                      <td>10-Jan-2018 , 04 PM</td>
                      <td>30 mins</td>
                      <td>Lorem</td>
                    </tr>
                  </table>
               </div>
            </div>
          </div>
        </div>
  </div>
</section>                                       
<?php include 'includes/dashboard_footer.php';?>