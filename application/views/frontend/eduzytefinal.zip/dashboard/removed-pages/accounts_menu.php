<div class="left-sidebar">
    <aside class="single-widget dashboard-side-menu">
        <h6 class="widget-title">Account Menu</h6>
        <div class="widget-content categories-widget">
            <ul>
                <li <?php if ($page == 'tutor_accounts.php') { ?>class="active"<?php } ?>><a href="tutor_accounts.php">Accounts</a></li>
                <li <?php if ($page == 'tutor_accounts_class_statements.php') { ?>class="active"<?php } ?>><a href="tutor_accounts_class_statements.php">Class Statements Notes </a></li>
            </ul>
        </div>
    </aside>
</div>