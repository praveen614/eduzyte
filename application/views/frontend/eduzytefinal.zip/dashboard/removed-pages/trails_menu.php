<div class="left-sidebar">
    <aside class="single-widget dashboard-side-menu">
        <h6 class="widget-title">Trails Menu</h6>
        <div class="widget-content categories-widget">
            <ul>
                <li <?php if ($page == 'tutor_trails_request.php') { ?>class="active"<?php } ?>><a href="tutor_trails_request.php">Trails Requested Scheduled</a></li>
                <li <?php if ($page == 'tutor_trails_decision.php') { ?>class="active"<?php } ?>><a href="tutor_trails_decision.php">Trails Decision Awaited</a></li>
                <li <?php if ($page == 'tutor_trails_successful.php') { ?>class="active"<?php } ?>><a href="tutor_trails_successful.php">Successful Trails</a></li>
                <li <?php if ($page == 'tutor_trails_unsuccessful.php') { ?>class="active"<?php } ?>><a href="tutor_trails_unsuccessful.php">Unsuccessful Trails</a></li>
            </ul>
        </div>
    </aside>
</div>