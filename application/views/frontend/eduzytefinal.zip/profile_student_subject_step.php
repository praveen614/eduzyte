<?php include 'includes/header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>REQUIRED SUBJECTS WITH TIMINGS</h2>
  </div>
</section>
<section id="how-it-works-area" class="ptb-60">
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-md-offset-1 profstep">
        <div class="about-app mt-0 profsingle-widget">
          <div class="progress mtmb-20">
          <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 70%">
            Page 2/3
          </div>
        </div>
          <div class="alert alert-success alert-dismissible fade in mb-0" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
            <i class="fa fa-check-circle fa-lg"></i> Personal Information Updated
          </div>
          <form action="profile_student_final_step.php">
          <div class="row">
            <div class="col-md-7">
              <h4>Required  Subjects And Timings</h4><hr>
              <div class="col-md-12 timeset">
              <div class="form-group">
               <label for=""><strong>Timezone </strong> <span class="txt_red">*</span></label> <br>
                (Enter correct time zone - it is important for scheduling of your classes.)
                <select class="form-control input-lg seexam"></select>
            </div>
            </div>
            <div class="col-md-12">
               <label>Study Level <span class="txt_red">*</span></label>
              <div class="form-group">
                <select class="form-control input-lg teach">
                  <option>-- Select --</option>
                  <option>Elementary (Grade 1 to Grade 5)</option>
                  <option>Secondary (Grade 6 to Grade 10)</option>
                  <option>Seniors Secondary (Grade 11 and Grade 12)</option>
                  <option>Skill Level (Graduation Onwards And All Competitive Exams)</option>
                </select>
              </div>
            </div>
            <div class="col-md-12">
                <div class="form-group optbtn">
                  <label>Subject / Course (One at a time) <span class="txt_red">*</span></label>
                  <select id="basic2" class="show-tick form-control" multiple>
                      <option disabled>Subjects</option>
                      <option>Acadamics</option>
                      <option>Accounting</option>
                      <option>Chemistry</option>
                      <option>Finance</option>
                      <option>Maths</option>
                      <option>Physics</option>
                      <option>Earth Science</option>
                      <option>Social Science</option>
                      <option>StatiStics</option>
                      <option>Botony</option>
                      <option>Zoology</option>
                      <option>Commerce</option>
                      <option>Economics</option>
                      <option>Geology</option>
                      <option>Political Science</option>
                      <option>Psychology</option> 
                      <option>Space Science</option>
                      <option>Philosophy</option>                      
                    </select>
                </div>
                <p style="margin-bottom: 5px"><a href="#addNewsubject" class="blulink" data-toggle="modal">If not in options in above, add a new subject</a></p>
            </div>
            <div class="form-group">
              <button type="button" class="btn pull-right mb-20 small-btn" data-toggle="modal" data-target="#addSubmsg"><i class="icofont icofont-plus-circle"></i> ADD SUBJECT</button>
            </div>
            </div>
            <div class="col-md-5">
              <table class="table table-bordered table-striped table-hover addsub mt-20">
                <tr>
                  <td>Maths(Grade 5 - Grade 12) <br>
                    3:00 - 4:00 PM
                  </td>
                  <td>
                    <a href="" class="btn greenbtn btn-sm btn-success"><i class="fa fa-edit"></i> EDIT</a>
                    <a href="" class="btn btn-sm btn-danger res-mgt-5"><i class="fa fa-trash-o"></i> DELETE</a>
                  </td>
                </tr>
                <tr>
                  <td>Finance(Grade 5 - Grade 12) <br> 4:00 - 5:00 PM</td>
                  <td>
                    <a href="" class="btn greenbtn btn-sm btn-success"><i class="fa fa-edit"></i> EDIT</a>
                    <a href="" class="btn btn-sm btn-danger res-mgt-5"><i class="fa fa-trash-o"></i> DELETE</a>
                  </td>
                </tr>
                <tr>
                  <td>Zoology(Grade 5 - Grade 12) <br> 6:00 - 7:00 PM</td>
                  <td>
                    <a href="" class="btn greenbtn btn-sm btn-success"><i class="fa fa-edit"></i> EDIT</a>
                    <a href="" class="btn btn-sm btn-danger res-mgt-5"><i class="fa fa-trash-o"></i> DELETE</a>
                  </td>
                </tr>
              </table>
            
            </div>
          </div><hr>
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
               <a href="<?=$_SERVER['HTTP_REFERER']?>" class="btn pull-left" ><i class="icofont icofont-simple-left res-mt-10"></i> BACK</a>
                
                <button type="submit" class="btn pull-right ml-5 res-mt-10">Go To Next Step <i class="fa fa-chevron-right"></i></button>
                <button type="submit" class="btn pull-right res-mt-10"><i class="icofont icofont-save"></i> SAVE</button> 
              </div>
            </div>
          </div>
</form>

        </div>
      </div>
    </div>
  </div>
</section>
<!-- app about area start -->
<script src="js/timezones.full.js"></script>
<script>
  $('.timeset select').timezones();
$('#basic2').selectpicker({
liveSearch: true,
maxOptions: 1
});
</script>
<?php include 'includes/footer.php';?>


<!-- Modal -->
<div class="modal fade" id="addNewsubject" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">     
      <div class="modal-body forgot">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Add A New Subject</h4> <hr>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label><strong>Subject Name</strong></label><br>                   
                <div class="input-group">
                  <div class="input-group-addon"><i class="fa fa-sticky-note-o fa-lg"></i></div>
                  <input type="text" class="form-control input-lg" placeholder="subject">
                </div>
                 <small class="text-danger text-center"><strong>Please add only one subject at a time.</strong></small>
              </div>    <hr>          
              <div class="form-group text-center">                
                <button type="submit" class="btn"><i class="icofont icofont-paper-plane"></i> SAVE</button> 
                <button type="submit" class="btn" data-dismiss="modal"><i class="icofont icofont-close"></i> CANCEL</button> 
              </div> 
                </div>
              </div>                             
                
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="addSubmsg" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">     
      <div class="modal-body forgot">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Add Subject</h4> <hr>
              <div class="row">
                <div class="col-md-12">
                  <p class="text-center">More than one subjects required more than one tutors <br> depents on your requirement. If you agree</p>   
              <hr>          
              <div class="form-group text-center">                
                <button type="submit" class="btn"><i class="icofont icofont-paper-plane"></i> OK</button> 
                <button type="submit" class="btn" data-dismiss="modal"><i class="icofont icofont-close"></i> CANCEL</button> 
              </div> 
                </div>
              </div>                             
                
      </div>
    </div>
  </div>
</div>