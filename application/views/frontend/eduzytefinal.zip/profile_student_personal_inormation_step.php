<?php include 'includes/header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>STUDENT INFORMATION FORM</h2>
  </div>
</section>
<section id="how-it-works-area" class="ptb-60">
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-md-offset-1 profstep">
        <div class="about-app mt-0 single-widget">
          <div class="progress mtmb-20">
          <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
            Page 1/3
          </div>
        </div>
         <form action="profile_student_subject_step.php" class="persform">
          <div class="row">
            <div class="col-md-12">
              <h4 class="blutxt">Personal Information</h4> <hr>
            </div>
          </div>
          
          <div class="col-md-3 col-sm-4">
            <div class="form-group">
              <label for=""><strong>Salutation</strong> <span>*</span></label>
                <select class="form-control input-lg intial">
                  <option>Select Salutation</option>
                  <option>Mr.</option>
                  <option>Ms.</option>
                  <option>Mrs.</option>
                  <option>Dr.</option>
                  <option>Other</option>
                </select>
            </div>
          </div> 
          <div class="col-md-3 col-sm-4">
            <div class="form-group">
              <label for=""><strong>First Name</strong> <span>*</span></label>
              <input type="text" class="form-control input-lg" value="Kumar">
            </div>            
          </div>
          <div class="col-md-3 col-sm-4">
            <div class="form-group">
              <label for=""><strong>Last Name</strong></label> 
              <input type="text" class="form-control input-lg" placeholder="Enter Lastname">
            </div>            
          </div>

          <div class="col-md-3 col-sm-4">
            <div class="form-group">
               <label for=""><strong>Display Name</strong> <span>*</span></label> 
            <input type="text" class="form-control input-lg" placeholder="Display Name">
            </div>
          </div>
          <div class="col-md-2 col-sm-6">
            <label for=""><strong>Gender</strong> <span>*</span></label>
            <div class="form-group">
              <select class="form-control input-lg teach">
                <option>Select</option>
                <option>Male</option>
                <option>Female</option>
                <option>Other</option>
              </select>
            </div>
          </div>
          <div class="col-md-5 col-sm-6">
            <label for=""><strong>Date of Birth</strong> <span>*</span></label>
            <div class="form-group">
              <input type="date" placeholder="Enter Date of Birth"  class="form-control input-lg">
            </div>
          </div>
          <div class="col-md-5 col-sm-6">
            <div class="form-group">
              <label for=""><strong>Currency </strong> <span>*</span></label>
              <select class="form-control input-lg teach">
                <option value="">Indian Rupee</option>
                <option value="">Dollor</option>
              </select> 
            </div>
          </div>
          <div class="col-md-12">
            <h4 class="blutxt">Communication Details</h4><hr>
          </div>
          <div class="col-md-12">
            <label for=""><strong>Address for Correspondence</strong></label>
            <div class="form-group"><span class="astred">*</span>
              <input type="text" class="form-control input-lg" placeholder="Address Line 1">
            </div>
          </div>
          <div class="col-md-12">
            <div class="form-group">
              <input type="text" class="form-control input-lg" placeholder="Address Line 2">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group"><span class="astred">*</span>
              <input type="text" class="form-control input-lg" placeholder="City/Town">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group"><span class="astred">*</span>
              <input type="text" class="form-control input-lg" placeholder="Zip/Postal Code *">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group"><span class="astred">*</span>
              <input type="text" class="form-control input-lg" placeholder="Landmark">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group"><span class="astred">*</span>
              <input type="text" class="form-control input-lg" placeholder="State/Province">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group"><span class="astred">*</span>
              <select class="input-lg form-control teach">
                <option value="">Country</option>
                <option value="">Afghanistan</option>
                <option value="">Albania</option>
                <option value="">Algeria</option>
                <option value="">Andorra</option>
                <option value="">Angola</option>
              </select>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group"><span class="astred">*</span>
              <input type="text" class="form-control input-lg" placeholder="Home Town">
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label for=""><strong>Contact Number</strong> <span>*</span></label>
              <input id="phone" type="tel" class="form-control input-lg" placeholder="Contact Number">
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label for=""><strong>Secondary Contact Number</strong></label>
              <input id="phone1" type="tel" class="form-control input-lg" placeholder="Secondary Contact Number">
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label for=""><strong>Whatsapp no</strong></label>
              <input id="phone2" type="tel" class="form-control input-lg" placeholder="Whatsapp No.">
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label for=""><strong>Skype ID</strong> <span>*</span></label>
              <div class="input-group">
                <div class="input-group-addon" style="background-color: #fff; border:1px solid #ccc; border-right:0px; color: #05adff"><i class="fa fa-skype fa-lg"></i></div>
                <input type="text" class="form-control input-lg" placeholder="Skype ID">
              </div>
            </div>
          </div>
          <div class="col-md-3" style="clear:both">
            <label for=""><strong>Qualification</strong> <span>*</span></label>
            <div class="form-group">
              <input type="text" class="form-control input-lg" placeholder="Qualification">
            </div>
          </div>
          <div class="col-md-3">
            <label for=""><strong>Subject</strong> <span>*</span></label>
            <div class="form-group">
              <input type="text" class="form-control input-lg" placeholder="Subject">
            </div>
          </div>
          <div class="col-md-3">
            <label for=""><strong>Institution Name</strong> <span>*</span></label>
            <div class="form-group">
              <input type="text" class="form-control input-lg" placeholder="Institution Name">
            </div>
          </div>
          <div class="col-md-3">
            <label for=""><strong>Year</strong> <span>*</span></label>
            <div class="form-group">
              <input type="text" class="form-control input-lg" placeholder="Year">
            </div>
          </div>
          <div class="col-md-12">
            <a href="#" class="mb-10 blutxt"><i class="fa fa-plus-circle"></i> Add More</a>
          </div>
          <div class="col-md-6">
            <label for=""><strong>Current Employer</strong></label>
            <div class="form-group">
              <input type="text" class="form-control input-lg" placeholder="Current Employer">
            </div>
          </div>
          <div class="col-md-6">
            <label for=""><strong>Designation</strong></label>
            <div class="form-group">
              <input type="text" class="form-control input-lg" placeholder="Designation">
            </div>
          </div>
          <div class="col-md-12 mb-10">
            <input type="checkbox"> Private
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for=""><strong>Email Address </strong> <span>*</span></label>
            <input type="text" class="form-control input-lg" value="Email Address">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for=""><strong>Alternative Email Address </strong></label>
            <input type="text" class="form-control input-lg" value="Email Address">
            </div>
          </div>
         
          <div class="col-md-6">
            <label for=""><strong>About Yourself</strong> <span>*</span></label>
            <div class="form-group">
              <textarea name="" id="" cols="10" rows="5" class="form-control"></textarea>
            </div>
          </div>
          <div class="col-md-6">
            <label for=""><strong>Your Objective</strong> <span>*</span></label>
            <div class="form-group">
              <textarea name="" id="" cols="10" rows="5" class="form-control"></textarea>
            </div>
          </div>
          <div class="col-md-6">
            <label for=""><strong>Profile Picture</strong> <span>*</span></label>
            <p class="mb-0">You can change your profile photo, otherwise the earlier uploaded photo will be maintained.</p>
            <div class="form-group">
              <input type="file" class="form-control input-lg">
            </div>
          </div>
          <div class="col-md-1 pt-60">(OR)</div>
          <div class="col-md-5">
            <label for=""><strong>Capture Picture</strong></label>
            <p class="mb-0">From your webcam<br>
            size : 180px X 180px</p>
            <div class="form-group">
              <input type="file" class="form-control input-lg">
            </div>
          </div>
          <!-- <div class="col-md-12">
            <label for=""><strong>Upload CV</strong></label>
            <div class="form-group">
              <input type="file" class="form-control input-lg">
            </div>
          </div> -->
          <div class="col-md-12">
            <h4 class="blutxt">Social Links</h4> <hr>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-facebook"></i></div>
                <input type="text" class="form-control input-lg" placeholder="Facebook Profile">
              </div>
            </div>
          </div> 
          <div class="col-md-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-twitter"></i></div>
                <input type="text" class="form-control input-lg" placeholder="Twitter Profile">
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-linkedin"></i></div>
                <input type="text" class="form-control input-lg" placeholder="Linkedin Profile">
              </div>
            </div>
          </div> 
          <div class="col-md-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-addon"><i class="fa fa-youtube"></i></div>
                <input type="text" class="form-control input-lg" placeholder="Video Credentials">
              </div>
            </div>
          </div>
          <div class="col-md-12"><hr>
            <div class="form-group">
          <a href="<?=$_SERVER['HTTP_REFERER']?>" class="btn pull-left" ><i class="icofont icofont-simple-left"></i> BACK</a>
        <button type="submit" class="btn pull-right res-mt-10"><i class="icofont icofont-save"></i> SAVE & CONTINUE</button>
      </div>
          </div>
         </form>
       
        </div>
      </div>
    </div>
  </div>
</section>
<!-- app about area start -->
<?php include 'includes/footer.php';?>
<script src="js/timezones.full.js"></script>
<link rel="stylesheet" href="css/intlTelInput.css">
<script src="js/intlTelInput.js"></script>
<script>
    $('.timeset select').timezones();
    $("#phone,#phone1,#phone2").intlTelInput({
      utilsScript: "js/utils.js"
    });
</script>

