<?php include 'includes/header.php';?>
<section id="slider-area" class="home-style-3 blue-grad-bg particle-bg">
  <div id="overlay"></div>
  <div class="img"></div>
  <div class="subbgheader">
    <h2>SUBJECTS YOU TEACH</h2>
  </div>
</section>
<section id="how-it-works-area" class="ptb-60">
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-md-offset-1 profstep">
        <div class="about-app mt-0 profsingle-widget">
          <div class="progress mtmb-20">
          <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 45%">
            Page 2/5
          </div>
        </div>
          <div class="alert alert-success alert-dismissible fade in mb-0" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
            <i class="fa fa-check-circle fa-lg"></i> Personal Information Updated
          </div>
          <form action="profile_add_more_qualifications_step.php">
          <div class="row">
            <div class="col-md-7">
              <h4>Add  Subjects</h4><hr>
            <div class="col-md-12">
               <label>Study Level <span class="txt_red">*</span></label>
              <div class="form-group">
                <select class="form-control input-lg teach">
                  <option>-- Select --</option>
                  <option>Elementary (Grade 1 to Grade 5)</option>
                  <option>Secondary (Grade 6 to Grade 10)</option>
                  <option>Seniors Secondary (Grade 11 and Grade 12)</option>
                  <option>Skill Level (Graduation Onwards And All Competitive Exams)</option>
                </select>
              </div>
            </div>
            <div class="col-md-6">
              <label>From Level <span class="txt_red">*</span></label>
              <div class="form-group">
                <select class="form-control input-lg teach">
                  <option>--Select Lowest Level--</option>
                  <option>--Skill Level--</option>
                  <option>Beginner</option>
                  <option>Intermediate</option>
                  <option>Expert</option>
                  <option>--Grades--</option>
                  <option>Grade 1</option>
                  <option>Grade 2</option>
                  <option>Grade 3</option>
                  <option>Grade 4</option>
                  <option>Grade 5</option>
                  <option>Grade 6</option>
                  <option>Grade 7</option>
                  <option>Grade 8</option>
                  <option>Grade 9</option>
                  <option>Grade 10</option>
                  <option>Grade 11</option>
                  <option>A levels</option>
                  <option>Grade 12</option>
                </select>
              </div>
            </div>
            <div class="col-md-6">
              <label>To Level <span class="txt_red">*</span></label>
              <div class="form-group">
                <select class="form-control input-lg teach">
                  <option>--Select Lowest Level--</option>
                  <option>--Skill Level--</option>
                  <option>Beginner</option>
                  <option>Intermediate</option>
                  <option>Expert</option>
                  <option>--Grades--</option>
                  <option>Grade 1</option>
                  <option>Grade 2</option>
                  <option>Grade 3</option>
                  <option>Grade 4</option>
                  <option>Grade 5</option>
                  <option>Grade 6</option>
                  <option>Grade 7</option>
                  <option>Grade 8</option>
                  <option>Grade 9</option>
                  <option>Grade 10</option>
                  <option>Grade 11</option>
                  <option>A levels</option>
                  <option>Grade 12</option>
                </select>
              </div>
            </div>
            <div class="col-md-12">
                <div class="form-group optbtn">
                  <label>Subject / Course (One at a time) <span class="txt_red">*</span></label>
                  <select id="basic2" class="show-tick form-control" multiple>
                      <option disabled>Subjects</option>
                      <option>Acadamics</option>
                      <option>Accounting</option>
                      <option>Chemistry</option>
                      <option>Finance</option>
                      <option>Maths</option>
                      <option>Physics</option>
                      <option>Earth Science</option>
                      <option>Social Science</option>
                      <option>StatiStics</option>
                      <option>Botony</option>
                      <option>Zoology</option>
                      <option>Commerce</option>
                      <option>Economics</option>
                      <option>Geology</option>
                      <option>Political Science</option>
                      <option>Psychology</option> 
                      <option>Space Science</option>
                      <option>Philosophy</option>                      
                    </select>
                </div>
                <p style="margin-bottom: 0px;"><a href="#addNewsubject" class="blulink" data-toggle="modal">If not in options in above, add a new subject</a></p>
            </div>
            <div class="form-group">
              <button type="submit" class="pull-right small-btn"><i class="icofont icofont-plus-circle"></i> ADD SUBJECT</button>
            </div>
            </div>

            <div class="col-md-5">
              <table class="table table-bordered table-striped table-hover addsub mt-20">
                <tr>
                  <td>Maths(Grade 5 - Grade 12)</td>
                  <td>
                    <a href="" class="btn greenbtn btn-sm btn-success"><i class="fa fa-edit"></i> EDIT</a>
                    <a href="" class="btn btn-sm btn-danger res-mgt-5"><i class="fa fa-trash-o"></i> DELETE</a>
                  </td>
                </tr>
                <tr>
                  <td>Finance(Grade 5 - Grade 12)</td>
                  <td>
                    <a href="" class="btn greenbtn btn-sm btn-success"><i class="fa fa-edit"></i> EDIT</a>
                    <a href="" class="btn btn-sm btn-danger res-mgt-5"><i class="fa fa-trash-o"></i> DELETE</a>
                  </td>
                </tr>
                <tr>
                  <td>Zoology(Grade 5 - Grade 12)</td>
                  <td>
                    <a href="" class="btn greenbtn btn-sm btn-success"><i class="fa fa-edit"></i> EDIT</a>
                    <a href="" class="btn btn-sm btn-danger res-mgt-5"><i class="fa fa-trash-o"></i> DELETE</a>
                  </td>
                </tr>
              </table>
            
            </div>
          </div><hr>
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
               <a href="<?=$_SERVER['HTTP_REFERER']?>" class="btn pull-left" ><i class="icofont icofont-simple-left res-mt-10"></i> BACK</a>
                
                <button type="submit" class="btn pull-right ml-5 res-mt-10">Go To Next Step <i class="fa fa-chevron-right"></i></button>
                <button type="submit" class="btn pull-right res-mt-10"><i class="icofont icofont-save"></i> SAVE</button> 
              </div>
            </div>
          </div>
</form>

        </div>
      </div>
    </div>
  </div>
</section>
<!-- app about area start -->
<?php include 'includes/footer.php';?>
<script>
$('#basic2').selectpicker({
liveSearch: true,
maxOptions: 1
});
</script>

<!-- Modal -->
<div class="modal fade" id="addNewsubject" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">     
      <div class="modal-body forgot">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Add A New Subject</h4> <hr>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label><strong>Subject Name</strong></label><br>                   
                <div class="input-group">
                  <div class="input-group-addon"><i class="fa fa-sticky-note-o fa-lg"></i></div>
                  <input type="text" class="form-control input-lg" placeholder="subject">
                </div>
                 <small class="text-danger text-center"><strong>Please add only one subject at a time.</strong></small>
              </div>    <hr>          
              <div class="form-group text-center">                
                <button type="submit" class="btn"><i class="icofont icofont-paper-plane"></i> SAVE</button> 
                <button type="submit" class="btn" data-dismiss="modal"><i class="icofont icofont-close"></i> CANCEL</button> 
              </div> 
                </div>
              </div>                             
                
      </div>
    </div>
  </div>
</div>